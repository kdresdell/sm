<?php

function pmlca_pmxi_extend_options_author($post_type){
	$lc_controller = new PMLCA_Admin_Import();
	$lc_controller->index($post_type);
}

?>