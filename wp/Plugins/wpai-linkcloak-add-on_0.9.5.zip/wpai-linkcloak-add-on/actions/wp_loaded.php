<?php

function pmlca_wp_loaded() {	

	// detect if cloaked link is requested and execute redirect.php if so
	if ( ! is_admin() and (preg_match('%^' . preg_quote(site_url_no_domain(PMLCA_Plugin::getInstance()->getOption('url_prefix')), '%') . '/([\w-]+)(/([^/?]+))?/?($|\?)%', $_SERVER['REQUEST_URI'], $mtch) or preg_match('%^' . preg_quote(site_url_no_domain(), '%') . '/?\?(.*?&)?cloaked=([\w-]+)(&|$)%', $_SERVER['REQUEST_URI'], $mtch_alt) or preg_match('%^' . preg_quote(site_url_no_domain(), '%') . '/?\?(.*?&)?link=([\w-]+)(&|$)%', $_SERVER['REQUEST_URI'], $mtch_alt))) {
			
		if ($mtch) {
			$slug = $mtch[1];
			$_GET['subid'] = $mtch[3];
		} else {
			$slug = $mtch_alt[2];
		}
		$link = new PMLCA_Link_Record();
		if ( ! $link->getBySlug($slug)->isEmpty() ) { // link is registered and not draft or preset
			$url = $link->afflink;
		
			if ( ! headers_sent()) {
				header('Cache-Control: no-cache');
		  		header('Pragma: no-cache');
			}
			
			header("Location: " . $url, true, 301);
			die;
		}

	}
}