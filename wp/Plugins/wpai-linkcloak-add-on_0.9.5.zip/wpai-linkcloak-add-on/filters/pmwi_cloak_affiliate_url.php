<?php

function pmlca_pmwi_cloak_affiliate_url( $aff_url, $import_id){

	$import = new PMXI_Import_Record();		

	if ( ! $import->getById($import_id)->isEmpty() ){		

		if ( empty($import->options['is_cloak']) and ! empty($import->options['pmlca_mode']) and ( in_array($import->options['pmlca_mode'], array("affiliate", "all")) ) )			

			return cloak_aff_links($aff_url, true);
	}

	return $aff_url; 

}

?>