<?php

function pmlca_pmxi_the_content($content, $import_id){
	
	$import = new PMXI_Import_Record();		

	if ( ! $import->getById($import_id)->isEmpty() ){

		if ( empty($import->options['is_cloak']) and ! empty($import->options['pmlca_mode']) and $import->options['pmlca_mode'] == "all" )

			return cloak_aff_links($content);
	}

	return $content; 

}

?>