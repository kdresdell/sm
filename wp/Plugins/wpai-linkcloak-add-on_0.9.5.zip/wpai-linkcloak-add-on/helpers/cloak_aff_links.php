<?php 

if ( ! function_exists('cloak_aff_links')):

	function cloak_aff_links( $content, $single_url = false ){
		
		if ($single_url){
					
			if (preg_match('%^\w+://%i', $content)) { // mask only links having protocol
				// try to find matching cloaked link among already registered ones

				$list = new PMLCA_Link_List(); $linkTable = $list->getTable();					
				$list->setColumns("$linkTable.*")->getBy(array(							
						"$linkTable.afflink LIKE" => $content,
					), NULL, 1, 1)->convertRecords();	

				if ($list->count()) { // matching link found
					$link = $list[0];
				} else { // register new cloaked link
					global $wpdb;
					$slug = max(							
						intval($wpdb->get_var("SELECT MAX(CONVERT(slug, SIGNED)) FROM $linkTable")),
						0
					);
					$i = 0; do {
						is_int(++$slug) and $slug > 0 or $slug = 1;
						$is_slug_found = ! intval($wpdb->get_var("SELECT COUNT(*) FROM $linkTable WHERE slug = '$slug'"));
					} while( ! $is_slug_found and $i++ < 100000);

					if ($is_slug_found) {						
						$link = new PMLCA_Link_Record(array(								
							'slug' => strval($slug),
							'afflink' => $content
						));
						$link->insert();							
					}
				}
									
				if ($link) { // cloaked link is found or created for url
					$content = preg_replace('%' . preg_quote($content, '%') . '(?=([\s\'"]|$))%i', $link->getUrl(), $content);
				}
			}
		}
		elseif (preg_match_all('%<a\s[^>]*href=(?(?=")"([^"]*)"|(?(?=\')\'([^\']*)\'|([^\s>]*)))%is', $content, $matches, PREG_PATTERN_ORDER)) {
			$hrefs = array_unique(array_merge(array_filter($matches[1]), array_filter($matches[2]), array_filter($matches[3])));
			foreach ($hrefs as $url) {
				if (preg_match('%^\w+://%i', $url)) { // mask only links having protocol
					// try to find matching cloaked link among already registered ones
					$list = new PMLCA_Link_List(); $linkTable = $list->getTable();					
					$list->setColumns("$linkTable.*")->getBy(array(							
							"$linkTable.afflink LIKE" => $url,
						), NULL, 1, 1)->convertRecords();					
					if ($list->count()) { // matching link found
						$link = $list[0];
					} else { // register new cloaked link
						global $wpdb;
						$slug = max(							
							intval($wpdb->get_var("SELECT MAX(CONVERT(slug, SIGNED)) FROM $linkTable")),
							0
						);
						$i = 0; do {
							is_int(++$slug) and $slug > 0 or $slug = 1;
							$is_slug_found = ! intval($wpdb->get_var("SELECT COUNT(*) FROM $linkTable WHERE slug = '$slug'"));
						} while( ! $is_slug_found and $i++ < 100000);

						if ($is_slug_found) {
							
							$link = new PMLCA_Link_Record(array(								
								'slug' => strval($slug),
								'afflink' => $url
							));
							$link->insert();							
						}
					}
										
					if ($link) { // cloaked link is found or created for url
						$content = preg_replace('%' . preg_quote($url, '%') . '(?=([\s\'"]|$))%i', $link->getUrl(), $content);
					}
				}
			}
		}
		return $content;
	}

endif; 

?>