<?php

class PMLCA_Link_List extends PMLCA_Model_List {
	
	public function __construct() {
		parent::__construct();
		$this->setTable(PMLCA_Plugin::getInstance()->getTablePrefix() . 'links');
	}
}