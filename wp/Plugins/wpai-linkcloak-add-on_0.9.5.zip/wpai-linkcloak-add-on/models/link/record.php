<?php

class PMLCA_Link_Record extends PMLCA_Model_Record {
	/**
	 * Initialize model instance
	 * @param array[optional] $data Array of record data to initialize object with
	 */
	public function __construct($data = array()) {
		parent::__construct($data);
		$this->setTable(PMLCA_Plugin::getInstance()->getTablePrefix() . 'links');
	}
	
	/**
	 * Create unique slug based on `name`
	 * @return string
	 */
	public function generateSlug() {
		$slug = '';
		if ($this->slug == '') {
			$slug = '1';
			$check = new self(); $alt = 1;
			while ( ! $check->getBy(array('slug LIKE' => $slug) + ( ! empty($this->id) ? array('id <>' => $this->id) : array()))->isEmpty()) {
				$slug = trim(preg_replace('%((^|-)\d+)?$%', "-$alt", $slug), '-');
				$alt++;
			}
			$this->slug = $slug;
		}
		return $slug;
	}
	/**
	 * Return full url which corresponds to this link
	 */
	public function getUrl($sub_id = NULL) {
		if ( ! empty($this->slug)) {
			$url = '';
			
			$url = site_url(PMLCA_Plugin::getInstance()->getOption('url_prefix') . '/' . ((PMLCA_Plugin::getInstance()->isPermalinks()) ? $this->slug : '?link=' . $this->slug));								
			if ( ! (is_null($sub_id) or '' === $sub_id)) {					
				$url .= '/' . (PMLCA_Plugin::getInstance()->isPermalinks()) ? $sub_id : '?link=' . $sub_id;
			}
			
			return $url;
		} else {
			return NULL;
		}
	}

	/**
	 * Return Tracking code for the link
	 * @param string $type Tracking code type: `header` or `footer`
	 */
	public function getTrackingCode($type) {
		$html = '';
		$field = $type . '_tracking_code';
		if ( ! $this->no_global_tracking_code) {
			$html .= PMLCA_Plugin::getInstance()->getOption($field);
		}
		$html .= $this->$field;
		return $html;
	}
	
	/**
	 * Fill current link with values from specified preset link
	 * @param PMLCA_Link_Record $preset Preset to apply
	 * @param bool[optional] $is_rewrite Whether to rewrite not empty fields
	 * @return bool
	 */
	public function applyPreset(PMLCA_Link_Record $preset, $is_rewrite = FALSE) {
		if ($preset->id != $this->id) {
			$this->getBy(array_intersect_key($this->toArray(TRUE), array_flip($this->primary))); // get data from database
			// copy ordinary fields
			foreach ($preset as $field => $value) {
				if ( ! in_array($field, $this->primary) and $field != 'preset' and ($is_rewrite or '' === $this->$field)) {
					$this->$field = $value;
				}
			}
			$this->update();					
			return TRUE;
		}
		return FALSE;
	}
	
	/**
	 * @see parent::delete()
	 */
	public function delete() {
		return parent::delete();
	}
	
}