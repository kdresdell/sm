<tr>
	<td colspan="3" style="padding-top:20px;">
		<fieldset class="optionsset pmli_options">
			<legend><?php _e('Link Cloaking Add-On','pmxi_plugin');?></legend>
			<div class="input">						
				<input type="radio" id="pmxilc_mode_no_<?php echo $post_type; ?>" class="switcher" name="pmlca_mode" value="no" <?php echo 'no' == $post['pmlca_mode'] ? 'checked="checked"': '' ?>/>
				<label for="pmxilc_mode_no_<?php echo $post_type; ?>"><?php _e('Do not cloak links', 'pmxi_plugin' )?></label><br>
				<input type="radio" id="pmxilc_mode_all_<?php echo $post_type; ?>" class="switcher" name="pmlca_mode" value="all" <?php echo 'all' == $post['pmlca_mode'] ? 'checked="checked"': '' ?>/>
				<label for="pmxilc_mode_all_<?php echo $post_type; ?>"><?php _e('Cloak all links present during import', 'pmxi_plugin' )?></label><br>
				<input type="radio" id="pmxilc_mode_affiliate_<?php echo $post_type; ?>" class="switcher" name="pmlca_mode" value="affiliate" <?php echo 'affiliate' == $post['pmlca_mode'] ? 'checked="checked"': '' ?>/>
				<label for="pmxilc_mode_affiliate_<?php echo $post_type; ?>"><?php _e('Only cloak WooCommerce External/Affiliate Product Buy URL ', 'pmxi_plugin' )?></label><br>				
			</div>
		</fieldset>		
	</td>
</tr>