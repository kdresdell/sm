<?php 

function pmui_delete_post($post_id) {
	
	$uid = get_post_meta($post_id, 'pmui_user_id', true);

	if ( ! empty($uid) ) wp_delete_user($uid);


}