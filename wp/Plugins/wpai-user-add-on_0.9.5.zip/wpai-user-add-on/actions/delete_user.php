<?php
function pmui_delete_user($uid){

	$import_users = get_posts(array(
		'post_type' => 'import_users',
		'meta_key' => 'pmui_user_id',
		'meta_value' => $uid
	));

	if ( ! empty($import_users) ) {
		foreach ($import_users as $key => $import_user) {
			$post = new PMXI_Post_Record();
			$post->get_by_post_id($import_user->ID)->isEmpty() or $post->delete();	
		}
	}
}
?>