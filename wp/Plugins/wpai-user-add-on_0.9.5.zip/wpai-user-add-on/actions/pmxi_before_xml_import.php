<?php
function pmui_pmxi_before_xml_import($import_id){
	
	$import = new PMXI_Import_Record();

	if ( ! $import->getById($import_id)->isEmpty() and $import->options['pmui']['import_users'] ){

		$template = $import->template;

		$template['title'] = $import['options']['pmui']['login'];
		$template['content'] = $import['options']['pmui']['email'];

		$import->set(array(
			'template' => $template
		))->update();

	}
}
?>