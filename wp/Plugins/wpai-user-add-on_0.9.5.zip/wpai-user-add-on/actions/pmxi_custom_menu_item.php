<?php
	function pmui_pmxi_custom_menu_item(){
		if (!empty($_GET['type']) and $_GET['type'] == 'user'):
		?>
		<a class="nav-tab" rel="import_users" href="javascript:void(0);"><?php _e('Users', 'pmxi_plugin'); ?></a>
		<?php
		endif;
	}
?>