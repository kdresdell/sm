<?php

function pmui_pmxi_custom_options_tab($isWizard, $post){

	if (!empty($_GET['type']) and $_GET['type'] == 'user'):

		$pmui_controller = new PMUI_Admin_Import();										
		
		$pmui_controller->index($post);

	endif;
		
}

?>