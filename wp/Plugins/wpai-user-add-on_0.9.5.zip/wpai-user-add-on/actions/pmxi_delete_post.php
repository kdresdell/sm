<?php
function pmui_pmxi_delete_post($pid){

	$ids = (!is_array($pid)) ? array($pid) : $pid;

	if ( ! empty($ids) ){
		foreach ($ids as $id) {
			$uid = get_post_meta($id, 'pmui_user_id', true);
			if ( ! empty($uid) ) wp_delete_user($uid);
		}
	}

}
?>