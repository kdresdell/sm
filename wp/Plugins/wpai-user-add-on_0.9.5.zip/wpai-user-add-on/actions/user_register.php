<?php
function pmui_user_register($user_id){

	$user = get_user_by('id', $user_id);

	$import_users = get_posts(array(
		'post_type' => 'import_users',
		'meta_key' => 'pmui_user_id',
		'meta_value' => $user->ID
	));

	if ( empty($import_users) ) {
		
		$pid = pmxi_insert_post(array(
			'post_type' => 'import_users',
			'post_title' => $user->user_login,
			'post_content' => $user->user_email,
			'post_status' => 'publish'
		));

		update_post_meta($pid, 'pmui_user_id', $user->ID);
	}

}

?>