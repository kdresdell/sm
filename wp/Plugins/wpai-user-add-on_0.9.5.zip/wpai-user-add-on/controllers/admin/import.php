<?php 
/**
 * Import configuration wizard
 * 
 * @author Max Tsiplyakov <makstsiplyakov@gmail.com>
 */

class PMUI_Admin_Import extends PMUI_Controller_Admin {		
	protected $isWizard = true;

	protected function init() {
		parent::init();							
		
		if ('PMXI_Admin_Manage' == PMXI_Plugin::getInstance()->getAdminCurrentScreen()->base) { // prereqisites are not checked when flow control is deligated			
			$this->isWizard = false;		
		}		
	}

	public function set($var, $val)
	{
		$this->{$var} = $val;
	}
	public function get($var)
	{
		return $this->{$var};
	} 

	/**
	 * Step #1: Choose File
	 */
	public function index( $post = array() ) {	

		$default = PMXI_Plugin::get_default_import_options() + PMUI_Plugin::get_default_import_options();	

		$this->data['isWizard'] = $this->isWizard;		

		$this->data['id'] = $id = $this->input->get('id');
		
		$this->data['is_loaded_template'] = (!empty(PMXI_Plugin::$session->data['pmxi_import']['is_loaded_template'])) ? PMXI_Plugin::$session->data['pmxi_import']['is_loaded_template'] : false;
		
		$this->data['post_type'] = $this->data['entry'] = 'import_users';

		$this->data['post'] =& $post;

		// Get All meta keys in the system
		$this->data['meta_keys'] = new PMXI_Model_List();
		$this->data['meta_keys']->setTable(PMXI_Plugin::getInstance()->getWPPrefix() . 'usermeta');
		$this->data['meta_keys']->setColumns('umeta_id', 'meta_key')->getBy(NULL, "umeta_id", NULL, NULL, "meta_key");	
		
		$this->render();

	}	
		
}
