<?php

function pmui_pmxi_admin_menu($menu){
		
	array_splice( $menu, 1, 0, array(array('pmxi-admin-import&type=user', __('New User Import', 'pmxi_plugin'))));

	return $menu;
}

?>