<?php

function pmui_pmxi_custom_field_to_delete($field_to_delete, $pid, $post_type, $options, $cur_meta_key){

	if ($cur_meta_key == 'pmui_user_id') return false;

}

?>