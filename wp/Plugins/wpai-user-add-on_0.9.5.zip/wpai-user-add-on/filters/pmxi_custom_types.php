<?php
	function pmui_pmxi_custom_types($custom_types){
		
		if ( ! empty($_GET['type']) and $_GET['type'] == 'user') 
			$custom_types = array();
		elseif( ! empty($custom_types['import_users']) ) 
			unset($custom_types['import_users']);

		return $custom_types;
	}
?>