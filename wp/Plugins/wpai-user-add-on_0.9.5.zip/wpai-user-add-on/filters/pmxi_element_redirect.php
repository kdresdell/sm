<?php
function pmui_pmxi_element_redirect($url){

	if (!empty($_GET['type']) and $_GET['type'] == 'user'):

		$url = add_query_arg('action', 'options', $url);

		if ( empty(PMXI_Plugin::$session->data['pmxi_import']['template']) ){			

			PMXI_Plugin::$session['pmxi_import']['template'] = array(
					'title' => 'user',
					'content' => 'user content'
			);

			pmxi_session_commit();

		}

	endif;

	return $url;
}
?>