<?php
function pmui_pmxi_import_actions($actions, $importArr){
	if ($importArr['options']['custom_type'] == 'import_users'){
		unset($actions['edit_template']);
		if (!empty($actions['edit_options']['url'])) $actions['edit_options']['url'] = add_query_arg(array('type' => 'user'), $actions['edit_options']['url']);
		if (!empty($actions['re_run_with_new_file']['url'])) $actions['re_run_with_new_file']['url'] = add_query_arg(array('type' => 'user'), $actions['re_run_with_new_file']['url']);
	}
	return $actions;
}
?>