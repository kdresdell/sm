<?php
function pmui_pmxi_options_back_link($url, $isWizard){

	if ($isWizard and !empty($_GET['type']) and $_GET['type'] == 'user'){
		$url = add_query_arg('action', 'element', $url);
	}
	else{
		$url = remove_query_arg('type', $url);
	}

	return $url;
}
?>