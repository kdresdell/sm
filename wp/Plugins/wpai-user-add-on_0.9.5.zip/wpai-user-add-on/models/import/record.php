<?php

class PMUI_Import_Record extends PMUI_Model_Record {		

	/**
	 * Associative array of data which will be automatically available as variables when template is rendered
	 * @var array
	 */
	public $data = array();

	public $parsing_data = array();

	/**
	 * Initialize model instance
	 * @param array[optional] $data Array of record data to initialize object with
	 */
	public function __construct($data = array()) { 
		parent::__construct($data);
		$this->setTable(PMXI_Plugin::getInstance()->getTablePrefix() . 'imports');
	}	
	
	/**
	 * Perform import operation
	 * @param string $xml XML string to import
	 * @param callback[optional] $logger Method where progress messages are submmitted
	 * @return PMUI_Import_Record
	 * @chainable
	 */
	public function parse($parsing_data = array()) { //$import, $count, $xml, $logger = NULL, $chunk = false, $xpath_prefix = ""		

		if ( ! $parsing_data['import']->options['pmui']['import_users'] ) return;

		add_filter('user_has_cap', array($this, '_filter_has_cap_unfiltered_html')); kses_init(); // do not perform special filtering for imported content			

		$cxpath = $parsing_data['xpath_prefix'] . $parsing_data['import']->xpath;

		$this->data = array();

		$records = array();

		$parsing_data['chunk'] == 1 and $parsing_data['logger'] and call_user_func($parsing_data['logger'], __('Composing users...', 'pmxi_plugin'));
		
		$xml = $parsing_data['xml'];

		if ( ! empty($parsing_data['import']->options['pmui']['login']) ) {
			$this->data['pmui_logins'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['login'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_logins'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['pass']) ) {
			$this->data['pmui_pass'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['pass'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_pass'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['nicename']) ) {
			$this->data['pmui_nicename'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['nicename'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_nicename'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['email']) ) {
			$this->data['pmui_email'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['email'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_email'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['registered']) ) {
			$this->data['pmui_registered'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['registered'], $file)->parse($records); $tmp_files[] = $file;				
			$warned = array(); // used to prevent the same notice displaying several times
			foreach ($this->data['pmui_registered'] as $i => $d) {
				if ($d == 'now') $d = current_time('mysql'); // Replace 'now' with the WordPress local time to account for timezone offsets (WordPress references its local time during publishing rather than the server’s time so it should use that)
				$time = strtotime($d);
				if (FALSE === $time) {
					in_array($d, $warned) or $logger and call_user_func($logger, sprintf(__('<b>WARNING</b>: unrecognized date format `%s`, assigning current date', 'pmxi_plugin'), $warned[] = $d));
					$logger and PMXI_Plugin::$session['pmxi_import']['warnings'] = ++PMXI_Plugin::$session->data['pmxi_import']['warnings'];
					$time = time();
				}
				$this->data['pmui_registered'][$i] = date('Y-m-d H:i:s', $time);
			}
		}
		else {
			$parsing_data['count'] and $this->data['pmui_registered'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['display_name']) ) {
			$this->data['pmui_display_name'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['display_name'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_display_name'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['url']) ) {
			$this->data['pmui_url'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['url'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_url'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['first_name']) ) {
			$this->data['pmui_first_name'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['first_name'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_first_name'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['last_name']) ) {
			$this->data['pmui_last_name'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['last_name'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_last_name'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['description']) ) {
			$this->data['pmui_description'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['description'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_description'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['nickname']) ) {
			$this->data['pmui_nickname'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['nickname'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_nickname'] = array_fill(0, $parsing_data['count'], '');
		}

		if ( ! empty($parsing_data['import']->options['pmui']['role']) ) {
			$this->data['pmui_role'] = XmlImportParser::factory($xml, $cxpath, $parsing_data['import']->options['pmui']['role'], $file)->parse($records); $tmp_files[] = $file;				
		}
		else {
			$parsing_data['count'] and $this->data['pmui_role'] = array_fill(0, $parsing_data['count'], '');
		}
			
		remove_filter('user_has_cap', array($this, '_filter_has_cap_unfiltered_html')); kses_init(); // return any filtering rules back if they has been disabled for import procedure					

		return $this->data;
	}

	public function import($importData = array()){ //$pid, $i, $import, $articleData, $xml, $is_cron = false, $xpath_prefix = ""

		if ( ! $importData['import']->options['pmui']['import_users'] ) return;		

		extract($importData);

		$cxpath = $xpath_prefix . $import->xpath;

		$userData = array(			
			'user_pass' => $this->data['pmui_pass'][$i],
			'user_login' => $this->data['pmui_logins'][$i],
			'user_nicename' => $this->data['pmui_nicename'][$i],
			'user_url' =>  $this->data['pmui_url'][$i],
			'user_email' =>  $this->data['pmui_email'][$i],
			'display_name' =>  $this->data['pmui_display_name'][$i],
			'user_registered' =>  $this->data['pmui_registered'][$i],
			'first_name' =>  $this->data['pmui_first_name'][$i],
			'last_name' =>  $this->data['pmui_last_name'][$i],
			'description' =>  $this->data['pmui_description'][$i],
			'nickname' => $this->data['pmui_nickname'][$i],
			'role' => ('' == $this->data['pmui_role'][$i]) ? 'subscriber' : $this->data['pmui_role'][$i],
		);

		if ( ! empty($articleData['ID']) ){
			
			$pmui_user_id = get_post_meta($pid, 'pmui_user_id', true);

			if ( ! empty($pmui_user_id)){

				$userData['ID'] = $pmui_user_id;

				$user = get_user_by('id', $userData['ID']);				

				if ( $import->options['update_all_data'] == "no" ){
					if ( ! $import->options['pmui']['is_update_first_name'] ) $userData['first_name'] = $user->first_name;
					if ( ! $import->options['pmui']['is_update_last_name'] ) $userData['last_name'] = $user->last_name;
					if ( ! $import->options['pmui']['is_update_role'] ) unset($userData['role']);
					if ( ! $import->options['pmui']['is_update_nickname'] ) $userData['nickname'] = get_user_meta($user->ID, 'nickname', true);
					if ( ! $import->options['pmui']['is_update_description'] ) $userData['description'] = get_user_meta($user->ID, 'description', true);
					if ( ! $import->options['pmui']['is_update_login'] ) $userData['user_login'] = $user->user_login; 
					if ( ! $import->options['pmui']['is_update_password'] ) unset($userData['user_pass']);
					if ( ! $import->options['pmui']['is_update_nicename'] ) $userData['user_nicename'] = $user->user_nicename;
					if ( ! $import->options['pmui']['is_update_email'] ) $userData['user_email'] = $user->user_email;
					if ( ! $import->options['pmui']['is_update_registered'] ) $userData['user_registered'] = $user->user_registered;
					if ( ! $import->options['pmui']['is_update_display_name'] ) $userData['display_name'] = $user->display_name;
					if ( ! $import->options['pmui']['is_update_url'] ) $userData['user_url'] = $user->user_url;
				}								
			}
		}	
	
		$uid = (empty($userData['ID'])) ? wp_insert_user( $userData ) : wp_update_user( $userData );		

		$user = get_user_by('id', $uid);

		$post_meta_keys = get_post_custom_keys($pid);
		if (empty($post_meta_keys) or !is_array($post_meta_keys)) $post_meta_keys = array();
		$meta_blacklist = array();
		$meta_keys = array_diff($post_meta_keys, $meta_blacklist);

		if (!empty($meta_keys)){
			foreach ($meta_keys as $meta_key) {
				
				$meta_values = get_post_custom_values($meta_key, $pid);

				foreach ($meta_values as $meta_value) {
					$meta_value = maybe_unserialize($meta_value);
					if ($meta_key != 'pmui_user_id') update_user_meta($uid, $meta_key, $meta_value);
				}

			}
		}

		if ( is_wp_error($uid) ) {
			$logger and call_user_func($logger, __('<b>ERROR</b>', 'pmxi_plugin') . ': ' . $uid->get_error_message());
			$logger and PMXI_Plugin::$session['pmxi_import']['errors'] = ++PMXI_Plugin::$session->data['pmxi_import']['errors'];
			wp_delete_post($pid);
		}
		else {
			update_post_meta($pid, 'pmui_user_id', $uid);
		}
		
	}

	public function _filter_has_cap_unfiltered_html($caps)
	{
		$caps['unfiltered_html'] = true;
		return $caps;
	}
	
	public function filtering($var){
		return ("" == $var) ? false : true;
	}		
}
