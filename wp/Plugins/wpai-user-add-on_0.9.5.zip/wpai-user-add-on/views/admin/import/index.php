<div id="import_users" >
	<form class="options" method="post">
		<input type="hidden" name="custom_type" value="<?php echo $post_type; ?>"/>
		<input type="hidden" name="type" value="post"/>

		<div class="post-type-options">
			<table class="form-table" style="max-width:none;">
				<?php					
					include( 'options/_main_options_template.php' );
					include( 'options/_custom_fields_template.php' );
					include( 'options/_reimport_template.php' );
					include( PMXI_ROOT_DIR . '/views/admin/import/options/_settings_template.php' );
				?>
			</table>
		</div>

		<?php include( PMXI_ROOT_DIR . '/views/admin/import/options/_buttons_template.php' ); ?>

	</form>
</div>