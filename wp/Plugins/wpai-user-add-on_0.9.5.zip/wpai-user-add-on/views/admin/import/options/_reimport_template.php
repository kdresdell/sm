<tr>
	<td colspan="3" style="padding-top:20px;">
		<fieldset class="optionsset">
			<legend><?php _e('Record Matching','pmxi_plugin');?></legend>		
			<div class="input" style="margin-bottom:15px; position:relative;">
				<input type="button" value="<?php _e('Click to see hints', 'pmxi_plugin');?>" class="button-primary pmxi_tips_pointer">				
				<input type="radio" id="auto_matching_<?php echo $post_type; ?>" class="switcher" name="duplicate_matching" value="auto" <?php echo 'manual' != $post['duplicate_matching'] ? 'checked="checked"': '' ?>/>
				<label for="auto_matching_<?php echo $post_type; ?>"><?php _e('Automatic User Matching', 'pmxi_plugin' )?></label><br>
				<div class="switcher-target-auto_matching_<?php echo $post_type; ?>"  style="padding-left:17px;">
					<div class="input">
						<label><?php _e("Unique key"); ?></label>
						
						<input type="text" class="smaller-text" name="unique_key" style="width:300px;" value="<?php echo esc_attr($post['unique_key']) ?>" <?php echo  ( ! $isWizard ) ? 'disabled="disabled"' : '' ?>/>
						<a href="#help" class="help" title="<?php _e('If users are being updated and not just created during a brand new import, the problem is that the value of the unique key is not unique for each record.', 'pmxi_plugin') ?>">?</a>
					</div>
				</div>
				<input type="radio" id="manual_matching_<?php echo $post_type; ?>" class="switcher" name="duplicate_matching" value="manual" <?php echo 'manual' == $post['duplicate_matching'] ? 'checked="checked"': '' ?>/>
				<label for="manual_matching_<?php echo $post_type; ?>"><?php _e('Manual User Matching', 'pmxi_plugin' )?></label>
				<div class="switcher-target-manual_matching_<?php echo $post_type; ?>" style="padding-left:17px;">
					<div class="input">						
						<input type="radio" id="duplicate_indicator_title_<?php echo $post_type; ?>" class="switcher" name="duplicate_indicator" value="title" <?php echo 'title' == $post['duplicate_indicator'] ? 'checked="checked"': '' ?>/>
						<label for="duplicate_indicator_title_<?php echo $post_type; ?>"><?php _e('match by Login', 'pmxi_plugin' )?></label><br>
						<input type="radio" id="duplicate_indicator_content_<?php echo $post_type; ?>" class="switcher" name="duplicate_indicator" value="content" <?php echo 'content' == $post['duplicate_indicator'] ? 'checked="checked"': '' ?>/>
						<label for="duplicate_indicator_content_<?php echo $post_type; ?>"><?php _e('match by Email', 'pmxi_plugin' )?></label><br>
						<input type="radio" id="duplicate_indicator_custom_field_<?php echo $post_type; ?>" class="switcher" name="duplicate_indicator" value="custom field" <?php echo 'custom field' == $post['duplicate_indicator'] ? 'checked="checked"': '' ?>/>
						<label for="duplicate_indicator_custom_field_<?php echo $post_type; ?>"><?php _e('match by Meta field', 'pmxi_plugin' )?></label><br>
						<span class="switcher-target-duplicate_indicator_custom_field_<?php echo $post_type; ?>" style="vertical-align:middle; padding-left:17px;">
							<?php _e('Name', 'pmxi_plugin') ?>
							<input type="text" name="custom_duplicate_name" value="<?php echo esc_attr($post['custom_duplicate_name']) ?>" />
							<?php _e('Value', 'pmxi_plugin') ?>
							<input type="text" name="custom_duplicate_value" value="<?php echo esc_attr($post['custom_duplicate_value']) ?>" />
						</span>
					</div>
				</div>
			</div>
			<hr>
			<div class="input">
				<input type="hidden" name="create_new_records" value="0" />
				<input type="checkbox" id="create_new_records_<?php echo $post_type; ?>" name="create_new_records" value="1" <?php echo $post['create_new_records'] ? 'checked="checked"' : '' ?> />
				<label for="create_new_records_<?php echo $post_type; ?>"><?php _e('Create new users from records newly present in your file', 'pmxi_plugin') ?></label>
			</div>
			<div class="input">
				<input type="hidden" name="is_delete_missing" value="0" />
				<input type="checkbox" id="is_delete_missing_<?php echo $post_type; ?>" name="is_delete_missing" value="1" <?php echo $post['is_delete_missing'] ? 'checked="checked"': '' ?> class="switcher"/>
				<label for="is_delete_missing_<?php echo $post_type; ?>"><?php _e('Delete users that are no longer present in your file', 'pmxi_plugin') ?></label>
				<a href="#help" class="help" title="<?php _e('Check this option if you want to delete users from the previous import operation which are not found among newly imported set.', 'pmxi_plugin') ?>">?</a>
			</div>
			<div class="switcher-target-is_delete_missing_<?php echo $post_type; ?>" style="padding-left:17px;">				
				<div class="input">
					<input type="hidden" name="is_update_missing_cf" value="0" />
					<input type="checkbox" id="is_update_missing_cf_<?php echo $post_type; ?>" name="is_update_missing_cf" value="1" <?php echo $post['is_update_missing_cf'] ? 'checked="checked"': '' ?> class="switcher"/>
					<label for="is_update_missing_cf_<?php echo $post_type; ?>"><?php _e('Instead of deletion, set Meta Field', 'pmxi_plugin') ?></label>
					<a href="#help" class="help" title="<?php _e('Check this option if you want to update users meta fields from the previous import operation which are not found among newly imported set.', 'pmxi_plugin') ?>">?</a>			
					<div class="switcher-target-is_update_missing_cf_<?php echo $post_type; ?>" style="padding-left:17px;">
						<div class="input">
							<?php _e('Name', 'pmxi_plugin') ?>
							<input type="text" name="update_missing_cf_name" value="<?php echo esc_attr($post['update_missing_cf_name']) ?>" />
							<?php _e('Value', 'pmxi_plugin') ?>
							<input type="text" name="update_missing_cf_value" value="<?php echo esc_attr($post['update_missing_cf_value']) ?>" />									
						</div>
					</div>
				</div>				
			</div>			
			<div class="input">
				<input type="hidden" id="is_keep_former_posts_<?php echo $post_type; ?>" name="is_keep_former_posts" value="yes" />				
				<input type="checkbox" id="is_not_keep_former_posts_<?php echo $post_type; ?>" name="is_keep_former_posts" value="no" <?php echo "yes" != $post['is_keep_former_posts'] ? 'checked="checked"': '' ?> class="switcher" />
				<label for="is_not_keep_former_posts_<?php echo $post_type; ?>"><?php _e('Update existing users with changed data in your file', 'pmxi_plugin') ?></label>

				<div class="switcher-target-is_not_keep_former_posts_<?php echo $post_type; ?>" style="padding-left:17px;">
					<input type="radio" id="update_all_data_<?php echo $post_type; ?>" class="switcher" name="update_all_data" value="yes" <?php echo 'no' != $post['update_all_data'] ? 'checked="checked"': '' ?>/>
					<label for="update_all_data_<?php echo $post_type; ?>"><?php _e('Update all data', 'pmxi_plugin' )?></label><br>
					
					<input type="radio" id="update_choosen_data_<?php echo $post_type; ?>" class="switcher" name="update_all_data" value="no" <?php echo 'no' == $post['update_all_data'] ? 'checked="checked"': '' ?>/>
					<label for="update_choosen_data_<?php echo $post_type; ?>"><?php _e('Choose which data to update', 'pmxi_plugin' )?></label><br>
					<div class="switcher-target-update_choosen_data_<?php echo $post_type; ?>"  style="padding-left:17px;">
						<div class="input">
							<input type="hidden" name="pmui[is_update_first_name]" value="0" />
							<input type="checkbox" id="is_update_first_name_<?php echo $post_type; ?>" name="pmui[is_update_first_name]" value="1" <?php echo $post['pmui']['is_update_first_name'] ? 'checked="checked"': '' ?> />
							<label for="is_update_first_name_<?php echo $post_type; ?>"><?php _e('First Name', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their first name.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_last_name]" value="0" />
							<input type="checkbox" id="is_update_last_name_<?php echo $post_type; ?>" name="pmui[is_update_last_name]" value="1" <?php echo $post['pmui']['is_update_last_name'] ? 'checked="checked"': '' ?> />
							<label for="is_update_last_name_<?php echo $post_type; ?>"><?php _e('Last Name', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their last name.', 'pmxi_plugin') ?>">?</a>
						</div>						
						<div class="input">
							<input type="hidden" name="pmui[is_update_role]" value="0" />
							<input type="checkbox" id="is_update_role_<?php echo $post_type; ?>" name="pmui[is_update_role]" value="1" <?php echo $post['pmui']['is_update_role'] ? 'checked="checked"': '' ?> />
							<label for="is_update_role_<?php echo $post_type; ?>"><?php _e('Role', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their role.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_nickname]" value="0" />
							<input type="checkbox" id="is_update_nickname_<?php echo $post_type; ?>" name="pmui[is_update_nickname]" value="1" <?php echo $post['pmui']['is_update_nickname'] ? 'checked="checked"': '' ?> />
							<label for="is_update_nickname_<?php echo $post_type; ?>"><?php _e('Nickname', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their nickname.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_description]" value="0" />
							<input type="checkbox" id="is_update_description_<?php echo $post_type; ?>" name="pmui[is_update_description]" value="1" <?php echo $post['pmui']['is_update_description'] ? 'checked="checked"': '' ?> />
							<label for="is_update_description_<?php echo $post_type; ?>"><?php _e('Description', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their description.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_login]" value="0" />
							<input type="checkbox" id="is_update_login_<?php echo $post_type; ?>" name="pmui[is_update_login]" value="1" <?php echo $post['pmui']['is_update_login'] ? 'checked="checked"': '' ?> />
							<label for="is_update_login_<?php echo $post_type; ?>"><?php _e('Login', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their login.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_password]" value="0" />
							<input type="checkbox" id="is_update_password_<?php echo $post_type; ?>" name="pmui[is_update_password]" value="1" <?php echo $post['pmui']['is_update_password'] ? 'checked="checked"': '' ?> />
							<label for="is_update_password_<?php echo $post_type; ?>"><?php _e('Password', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their password.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_nicename]" value="0" />
							<input type="checkbox" id="is_update_nicename_<?php echo $post_type; ?>" name="pmui[is_update_nicename]" value="1" <?php echo $post['pmui']['is_update_nicename'] ? 'checked="checked"': '' ?> />
							<label for="is_update_nicename_<?php echo $post_type; ?>"><?php _e('Nicename', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their nicename.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_email]" value="0" />
							<input type="checkbox" id="is_update_email_<?php echo $post_type; ?>" name="pmui[is_update_email]" value="1" <?php echo $post['pmui']['is_update_email'] ? 'checked="checked"': '' ?> />
							<label for="is_update_email_<?php echo $post_type; ?>"><?php _e('Email', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their email.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_registered]" value="0" />
							<input type="checkbox" id="is_update_registered_<?php echo $post_type; ?>" name="pmui[is_update_registered]" value="1" <?php echo $post['pmui']['is_update_registered'] ? 'checked="checked"': '' ?> />
							<label for="is_update_registered_<?php echo $post_type; ?>"><?php _e('Registered Date', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their registered date.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_display_name]" value="0" />
							<input type="checkbox" id="is_update_display_name_<?php echo $post_type; ?>" name="pmui[is_update_display_name]" value="1" <?php echo $post['pmui']['is_update_display_name'] ? 'checked="checked"': '' ?> />
							<label for="is_update_display_name_<?php echo $post_type; ?>"><?php _e('Display Name', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their display name.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">
							<input type="hidden" name="pmui[is_update_url]" value="0" />
							<input type="checkbox" id="is_update_url_<?php echo $post_type; ?>" name="pmui[is_update_url]" value="1" <?php echo $post['pmui']['is_update_url'] ? 'checked="checked"': '' ?> />
							<label for="is_update_url_<?php echo $post_type; ?>"><?php _e('URL', 'pmxi_plugin') ?></label>
							<a href="#help" class="help" title="<?php _e('Check this option if you want previously imported users to change their URL.', 'pmxi_plugin') ?>">?</a>
						</div>
						<div class="input">			
							<input type="hidden" name="custom_fields_list" value="0" />			
							<input type="hidden" name="is_update_custom_fields" value="0" />
							<input type="checkbox" id="is_update_custom_fields_<?php echo $post_type; ?>" name="is_update_custom_fields" value="1" <?php echo $post['is_update_custom_fields'] ? 'checked="checked"': '' ?>  class="switcher"/>
							<label for="is_update_custom_fields_<?php echo $post_type; ?>"><?php _e('Meta Fields', 'pmxi_plugin') ?></label>
							<!--a href="#help" class="help" title="<?php _e('If Keep Custom Fields box is checked, it will keep all Custom Fields, and add any new Custom Fields specified in Custom Fields section, as long as they do not overwrite existing fields. If \'Only keep this Custom Fields\' is specified, it will only keep the specified fields.', 'pmxi_plugin') ?>">?</a-->
							<div class="switcher-target-is_update_custom_fields_<?php echo $post_type; ?>" style="padding-left:17px;">
								<div class="input">
									<input type="radio" id="update_custom_fields_logic_full_update_<?php echo $post_type; ?>" name="update_custom_fields_logic" value="full_update" <?php echo ( "full_update" == $post['update_custom_fields_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
									<label for="update_custom_fields_logic_full_update_<?php echo $post_type; ?>"><?php _e('Update all Meta Fields', 'pmxi_plugin') ?></label>								
								</div>
								<?php
								$existing_meta_keys = array();
								$hide_fields = array('first_name', 'last_name', 'nickname', 'description', 'wp_capabilities');
								if (!empty($meta_keys) and $meta_keys->count()):
									foreach ($meta_keys as $meta_key) { if (in_array($meta_key['meta_key'], $hide_fields) or strpos($meta_key['meta_key'], '_wp') === 0) continue;
										$existing_meta_keys[] = $meta_key['meta_key'];												
									}
								endif;
								?>	
								<div class="input">
									<input type="radio" id="update_custom_fields_logic_only_<?php echo $post_type; ?>" name="update_custom_fields_logic" value="only" <?php echo ( "only" == $post['update_custom_fields_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
									<label for="update_custom_fields_logic_only_<?php echo $post_type; ?>"><?php _e('Update only these Meta Fields, leave the rest alone', 'pmxi_plugin') ?></label>								
									<div class="switcher-target-update_custom_fields_logic_only_<?php echo $post_type; ?> pmxi_choosen" style="padding-left:17px;">
											
										<span class="hidden choosen_values"><?php if (!empty($existing_meta_keys)) echo implode(',', $existing_meta_keys);?></span>
										<input class="choosen_input" value="<?php if (!empty($post['custom_fields_list']) and "only" == $post['update_custom_fields_logic']) echo implode(',', $post['custom_fields_list']); ?>" type="hidden" name="custom_fields_only_list"/>										
									</div>
								</div>
								<div class="input">
									<input type="radio" id="update_custom_fields_logic_all_except_<?php echo $post_type; ?>" name="update_custom_fields_logic" value="all_except" <?php echo ( "all_except" == $post['update_custom_fields_logic'] ) ? 'checked="checked"': '' ?> class="switcher"/>
									<label for="update_custom_fields_logic_all_except_<?php echo $post_type; ?>"><?php _e('Leave these fields alone, update all other Meta Fields', 'pmxi_plugin') ?></label>								
									<div class="switcher-target-update_custom_fields_logic_all_except_<?php echo $post_type; ?> pmxi_choosen" style="padding-left:17px;">
										
										<span class="hidden choosen_values"><?php if (!empty($existing_meta_keys)) echo implode(',', $existing_meta_keys);?></span>
										<input class="choosen_input" value="<?php if (!empty($post['custom_fields_list']) and "all_except" == $post['update_custom_fields_logic']) echo implode(',', $post['custom_fields_list']); ?>" type="hidden" name="custom_fields_except_list"/>																				
									</div>
								</div>
							</div>
						</div>							
					</div>
				</div>
			</div>				
		</fieldset>
	</td>
</tr>