<?php

function pmli_pmxi_manage_imports_columns($columns){	

	$columns['langs'] = __("Translations (WPML)", "pmxi_plugin");
	return $columns;
}

?>