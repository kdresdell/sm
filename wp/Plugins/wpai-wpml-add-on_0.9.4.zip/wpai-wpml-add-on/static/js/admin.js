/**
 * plugin admin area javascript
 */
(function($){$(function () {
	
	if ( ! $('body.pmxi_plugin').length) return; // do not execute any code if we are not on plugin page

	
});})(jQuery);
