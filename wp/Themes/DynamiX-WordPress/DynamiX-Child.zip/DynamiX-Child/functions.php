<?php 
/**
 * DynamiX Child Theme Functions
 * Load languages directory for translation
*/ 