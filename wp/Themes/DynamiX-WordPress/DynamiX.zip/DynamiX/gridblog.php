<?php
/**
 * @package WordPress
 * @subpackage NorthVantage
*/

/*
Template Name: Grid Blog
*/ 

global $NV_postlayout;

$NV_postlayout = "grid";

require "blog.php"; // get blog template