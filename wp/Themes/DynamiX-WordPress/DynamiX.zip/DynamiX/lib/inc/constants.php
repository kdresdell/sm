<?php 

/* ------------------------------------
:: CONSTANTS
------------------------------------*/

define( 'DEFAULT_SKIN', of_get_option("default_skin"));
define( 'NVFONTTYPE', of_get_option("nv_font_type"));