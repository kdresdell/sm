<?php
  global $data;
      include('category_template1.php');

?>