<?php
global $data; 
$use_bg = ''; $background = ''; $custom_bg = ''; $body_face = ''; $use_bg_header =''; $background_header = ''; $custom_bg_header = '';

if(isset($data['background_image'])) {
	$use_bg = $data['background_image'];
}


if(isset($data['background_image_header'])) {
	$use_bg_header = $data['background_image_header'];
}

if($use_bg) {

	$custom_bg = $data['body_bg_custom'];
	
	if(!empty($custom_bg)) {
		$bg_img = $custom_bg;
	} else {
		$bg_img = $data['body_bg'];
	}
	
	$bg_prop = $data['body_bg_properties'];
	
	$background = 'url('. $bg_img .') '.$bg_prop ;

}




function ieOpacity($opacityIn){
	
	$opacity = explode('.',$opacityIn);
	if($opacity[0] == 1)
		$opacity = 100;
	else
		$opacity = $opacity[1] * 10;
		
	return $opacity;
}

function HexToRGB($hex,$opacity) {
		$hex = preg_replace("/#/", "", $hex);
		$color = array();
 
		if(strlen($hex) == 3) {
			$color['r'] = hexdec(substr($hex, 0, 1) . $r);
			$color['g'] = hexdec(substr($hex, 1, 1) . $g);
			$color['b'] = hexdec(substr($hex, 2, 1) . $b);
		}
		else if(strlen($hex) == 6) {
			$color['r'] = hexdec(substr($hex, 0, 2));
			$color['g'] = hexdec(substr($hex, 2, 2));
			$color['b'] = hexdec(substr($hex, 4, 2));
		}
 
		return 'rgba('.$color['r'] .','.$color['g'].','.$color['b'].','.$opacity.')';
	}
	


?>
::selection { background: <?php echo $data['mainColor']; ?>; color: #fff; text-shadow: none; }
body {	 
	background:<?php echo $data['body_background_color'].' '.$background ?>  !important;
	color:<?php echo $data['body_font']['color']; ?>;
	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif;
	font-size: <?php echo $data['body_font']['size']; ?>;
	font-weight: normal;
	line-height: 1.65em;
	letter-spacing: normal;
}
h1,h2,h3,h4,h5,h6, .blogpostcategory .posted-date p, .team .title, .term-description p{
	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['heading_font']['face'])))); ?> !important;
	<?php if(strpos($data['heading_font']['face'],'200')) {?>
		font-weight: 300;
	<?php } else { ?>
		font-weight: normal;
	<?php }  ?>
	line-height: 110%;
}

h1 { 	
	color:<?php echo $data['heading_font_h1']['color']; ?>;
	font-size: <?php echo $data['heading_font_h1']['size'] ?> !important;
	}
	
h2, .term-description p { 	
	color:<?php echo $data['heading_font_h2']['color']; ?>;
	font-size: <?php echo $data['heading_font_h2']['size'] ?> !important;
	}

h3 { 	
	color:<?php echo $data['heading_font_h3']['color']; ?>;
	font-size: <?php echo $data['heading_font_h3']['size'] ?> !important;
	}

h4 { 	
	color:<?php echo $data['heading_font_h4']['color']; ?>;
	font-size: <?php echo $data['heading_font_h4']['size'] ?> !important;
	}	
	
h5 { 	
	color:<?php echo $data['heading_font_h5']['color']; ?>;
	font-size: <?php echo $data['heading_font_h5']['size'] ?> !important;
	}	

h6 { 	
	color:<?php echo $data['heading_font_h6']['color']; ?>;
	font-size: <?php echo $data['heading_font_h6']['size'] ?> !important;
	}	
h2.title a {color:<?php echo $data['heading_font_h2']['color']; ?>;}
a, a:active, a:visited, .footer_widget .widget_links ul li a{color: <?php echo $data['body_link_coler']; ?>;}	
.widget_nav_menu ul li a  {color: <?php echo $data['body_link_coler']; ?> !important;}
a:hover, h2.title a:hover, .item3 h3:hover, .item4 h3:hover, .item3 h3 a:hover, #portitems2 h3 a:hover {color: <?php echo $data['mainColor']; ?>;}
.item3 h3, .item4 h3, .item3 h3 a, .item4 h3 a, .item3 h4, .item2 h4, .item4 h4, #portitems2 h3 a {color:<?php echo $data['heading_font_h3']['color']; ?>;}
/* ***********************
--------------------------------------
------------NIVO SLIDER----------
--------------------------------------
*********************** */
.homeBox h2 a {color:<?php echo $data['heading_font_h3']['color']; ?>;}
.nivo-caption { 
	position:absolute; 
	background-color: <?php echo$data['slider_backColorNivo'] ?>;
	background-color: <?php echo HexToRGB($data['slider_backColorNivo'],$data['slider_opacity'])?>;
	border: 1px solid <?php echo $data['slider_borderColorNivo']; ?>; 
	color: <?php echo $data['slider_fontSize_colorNivo']['color']; ?>; 
	font-size: <?php echo $data['slider_fontSize_colorNivo']['size']; ?>;
	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['heading_font']['face'])))); ?> !important;
	text-shadow:0 1px 0 <?php echo HexToRGB($data['ShadowColorFont'],$data['ShadowOpacittyColorFont'])?>;
	letter-spacing: normal;
	padding:5px 15px 5px 5px;
	z-index:99;
	top:50px;
	left:0px;
	text-align:center;
	line-height:120%;
}
a.nivo-nextNav , a.nivo-prevNav {background: url(images/sponsorsArrowsForward.png) 3px 0  <?php echo$data['slider_backColorNivo'] ?>;background: url(images/sponsorsArrowsForward.png) 3px 0  <?php echo HexToRGB($data['slider_backColorNivo'],$data['slider_opacity'])?>;}
a.nivo-prevNav {background: url(images/sponsorsArrowsBack.png) 2px 0  <?php echo$data['slider_backColorNivo'] ?>;background: url(images/sponsorsArrowsBack.png) 2px 0  <?php echo HexToRGB($data['slider_backColorNivo'],$data['slider_opacity'])?>;}

.nivo-caption a { 
	color: <?php echo $data['slider_fontSize_colorNivo']['color']; ?>;  
	text-decoration: underline; 
}	

.caption-content { padding:0px 0px 200px 0px; color:<?php echo $data['slider_fontSize_color']['color']; ?>; font-size: <?php echo $data['slider_fontSize_color']['size']; ?>; font-family: <?php echo str_replace("%20"," ",$data['']['face']); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif; text-shadow: 1px 1px 0px black; filter:alpha(opacity=<?php echo ieOpacity($data['slider_opacity']); ?>);letter-spacing: normal;}
.caption-content h1{width:250px !important; background: <?php echo HexToRGB($data['mainColor'],$data['slider_opacity']) ?>;  padding:10px ;text-align:center;  line-height:120%;}
.caption-content h2 {	color:<?php echo $data['slider_fontSize_color']['color'] ;?>!important;
						font-size:<?php echo $data['slider_fontSize_color']['size'] ;?>!important;
						text-shadow: 1px 1px 0px black;}
.caption-content p{ }




.caption-content h1{
	color:<?php echo $data['slider_HfontSize_color']['color'] ;?>!important;
	font-size:<?php echo $data['slider_HfontSize_color']['size'] ;?>!important;
	text-shadow: 1px 1px 0px black;
}

.caption-content h2{
	background: <?php echo HexToRGB($data['slider_backColor'], $data['slider_opacity']); ?>;  padding:10px ;text-align:center;  line-height:120%;
}

#headerwrap, .homeRacent h2 ,.advertise h2,.slider-category .anythingBase,#nslider img, h3#comments ,.related h3, .widget h3, .projectdescription h3, .portsingle .portfolio h3, .titleborderh, .menu-header,
.socialsingle h2{
	background:<?php echo $data['body_background_color'].' '.$background  ?>  !important;
	}

/* ***********************
--------------------------------------
------------MAIN COLOR----------
--------------------------------------
*********************** */

.catlinkhover,.item h3 a:hover, .item2 h3 a:hover, .item4 h3 a:hover,.homeRacent h3:hover,.catlink:hover,.infotext span, .homeRacent h3 a:hover,
.blogpost .link:hover,.blogpost .postedin:hover ,.blogpost .postedin:hover, .blogpost .link a:hover,.blogpostcategory a.textlink:hover,
.footer_widget .widget_links ul li a:hover, .footer_widget .widget_categories  ul li a:hover,  .footer_widget .widget_archive  ul li a:hover,
#footerb .footernav ul li a:hover,.footer_widget  ul li a:hover,.tags span a:hover,.more-link:hover,.homeBox .one_third a,.showpostpostcontent h1 a:hover,
.menu li a:hover,.menu li a:hover strong, .menu li ul li:hover ul li:hover a,.menu li ul li,
.menu > li.current-menu-item a strong,.menu > li.current-menu-ancestor a strong,.blogpostcategory .meta .written:hover a ,.blogpostcategory .meta .comments:hover a ,
#wp-calendar a , .widgett a:hover ,.widget_categories li.current-cat a, .widget_categories li.current-cat, .blogpostcategory .meta .time a:hover,.homeRacent h2 span, .advertise h2 span, 
.widget span , .related h3 span, .homeremove .catlink .sortingword:hover, .homeremove .catlinkhover .sortingword, .accordion a, .blogpost .datecomment  .link a,
.titleborderh span, .textSlide .box, .textSlide .button a, a.recentmore, .blogpostcategory .blogmore, .top-nav a:hover, .widget_login p a:hover, .priceSP ins, .single_variation .price,
.homeRacent .productF h3.category, .homeRacent .productR h3.category, .single_variation ins, .textSlide .salePrice1 a, .textSlide .salePrice2 a, .textSlide .salePrice3 a, .cart_list.product_list_widget li .amount,
table.shop_table .cart_table_item .product-name a, table.order_details .product-name a, .cartTopDetails .total .amount, .cartTopDetails .product_list_widget li a:hover, .menu .pmcbig .pmcmenutitle > a,.menu .pmcbig .menufeautured span
{color:<?php echo $data['mainColor']; ?> !important;}

.socialsingle h2 span, .homeRacent h2 span, .advertise h2 span, .related h3 span, .infotext span,  .portfolio h3 span, .portsingleshare span, .titleborderh span,
.blogpostcategory .meta .category a, .tags a, .blogpost .posted-date a, .item4 h4 a, #portitems2 .category a, .homeRacent .category a
{background:<?php echo $data['mainColor']; ?> !important; color:#fff !important;text-shadow:0 1px 0 <?php echo HexToRGB($data['ShadowColorFont'],$data['ShadowOpacittyColorFont'])?>;padding:2px 6px 3px 6px; }
.widget del .amount {background:none !important;}


.advertise .bx-wrapper:hover .bx-next{background: <?php echo $data['mainColor']; ?> url(images/sponsorsArrowsForward.png) no-repeat;margin-left:935px;}
.advertise .bx-wrapper:hover .bx-prev {background: <?php echo $data['mainColor']; ?> url(images/sponsorsArrowsBack.png) no-repeat;margin-left:0px;}
 .page .homeRacent .bx-next,.portprev ,.homeRacent.SP .bx-next{background: <?php echo $data['mainColor']; ?> url(images/sponsorsArrowsForward.png) no-repeat;}
 .page .homeRacent .bx-prev,.portnext ,.homeRacent.SP .bx-prev {background: <?php echo $data['mainColor']; ?> url(images/sponsorsArrowsBack.png) no-repeat;}
.nextbutton.port {background: <?php echo $data['mainColor']; ?> url(images/sponsorsArrowsForward.png) no-repeat 0px -2px;}
.prevbutton.port {background: <?php echo $data['mainColor']; ?> url(images/sponsorsArrowsBack.png) no-repeat 0px -2px;}
.homeRacent .overLowerDefault,#portitems2 .overLowerDefault , .item3 .overLowerDefault, .item4 .overLowerDefault {background: <?php echo $data['mainColor']; ?> url(images/magnifyingGlassOverIcon.png);  }

.homeRacent .productR .recentdescription .onsale {border-color: <?php echo $data['mainColor']; ?> transparent <?php echo $data['mainColor']; ?>  <?php echo $data['mainColor']; ?>;text-shadow:0 1px 0 <?php echo HexToRGB($data['ShadowColorFont'],$data['ShadowOpacittyColorFont'])?>;}
/* ***********************
--------------------------------------
------------BOX COLOR----------
--------------------------------------
*********************** */
.homeBox .first {background:<?php echo $data['box1_color']; ?>;}
.homeBox .second {background:<?php echo $data['box2_color']; ?>;}
.homeBox .third {background:<?php echo $data['box3_color']; ?>;}
#footer, #homeRecent .one_fourth, .item3 h3, .item4 h3, .item3 h3 a, .item4 h3 a ,.homewrap .homesingleleft,.homewrap .homesingleright

{ background:<?php echo $data['boxColor']; ?>}
.homeRacent h3 a, .item4 h3, .item4 h3 a {color:<?php echo $data['body_font']['color']; ?>;}
#remove a, #remove a span{color:<?php echo $data['body_font']['color']; ?>;font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif;} 

/* ***********************
--------------------------------------
------------BOX FONT COLOR----------
--------------------------------------
*********************** */

.homeBox .one_fourth h2 a, .homeRacent h3.category a, .blogpostcategory .meta .category a, .tags a, .blogpost .posted-date a, .item4 h4 a, #portitems2 h3.category a, .team .role,.portcategories a,
.wp-pagenavi a:hover, .wp-pagenavi span.current, #respond #commentform input#commentSubmit, #contactform .contactbutton .contact-button, .blogpostcategory .comment-inside a, .blogpostcategory .date-inside,
.content ol.commentlist li .reply a, #commentform #respond #commentform input#commentSubmit, #respond #commentform input#commentSubmit, .pagecontent h1, .pagecontent p, .pagecontent p a, .homeRacent h3.category a:hover,
.homeremove .catlink span, .errorpage .postcontent h2, .errorpage .posttext, .blogpostcategory .date-inside .day, .blogpostcategory .date-inside .month, .textSlide span,textSlide .quote, textSlide .quote2
 {color: <?php echo $data['body_box_coler']; ?> !important;}
.homeremove .catlinkhover .sortingword, .homeremove .catlink .sortingword:hover  {background:<?php echo $data['body_box_coler']; ?>;}
/* ***********************
--------------------------------------
------------MAIN COLOR BOXED----------
--------------------------------------
*********************** */
#contactform  .contactbutton .contact-button:hover, .gototop ,.role, .team .icon img,.pagewrap, .blogpostcategory .posted-date .date-inside, #slider-wrapper,
.errorpage, .content ol.commentlist li .reply a, .blogpostcategory .comment-inside, ins, .widget_login .submitbutton, .widget_price_filter .ui-slider .ui-slider-handle,
.widget_price_filter .ui-widget-content, .item4 .image, .item3 .image, .item2 .image, table.shop_table .carButtons .button:hover, table.shop_table .coupon .button:hover, .cartTopDetails .product_list_widget .buttons a:hover,
.widget_price_filter  .price_slider_amount .button:hover, .variations_form.cart .single_add_to_cart_button:hover, .homeRacent .productR .recentdescription .onsale, .add_to_wishlist:hover,
.yith-wcwl-wishlistexistsbrowse:hover, .yith-wcwl-wishlistaddedbrowse:hover, table.cart a.remove:hover
{background:<?php echo $data['mainColor']; ?>;}

#yith-wcwl-form  table.cart a.remove:hover {background:<?php echo $data['mainColor']; ?> url(images/remove.png) no-repeat 4px 4px;}
.item2 .image {background:<?php echo $data['mainColor']; ?> !important;}
#fancybox-close:hover, .cartWrapper {background:<?php echo $data['mainColor']; ?> !important;}
ins {color:#fff !important;}
.wp-pagenavi a:hover, .wp-pagenavi span.current,#respond #commentform input#commentSubmit, #contactform  .contactbutton .contact-button, a.button, button.button, input.button, #respond input#submit, #content input.button,
a.button:hover, button.button:hover, input.button:hover, #respond input#submit:hover, #content input.button:hover, 
.widget_shopping_cart .total .amount, .product_list_widget li .amount, .titleSP h2, mark, .homeRacent .productF .recentCart a:hover, .homeRacent .productR .recentCart a:hover
  {background:<?php echo $data['mainColor']; ?>; text-shadow:0 1px 0 <?php echo HexToRGB($data['ShadowColorFont'],$data['ShadowOpacittyColorFont'])?>;}
.blogpostcategory .comment-inside a, .blogpostcategory .date-inside, .textSlide span,textSlide .quote, textSlide .quote2, .textSlide li {color: <?php echo $data['body_box_coler']; ?> !important; text-shadow:0 1px 0 <?php echo HexToRGB($data['ShadowColorFont'],$data['ShadowOpacittyColorFont'])?>;}
.textSlide .button, .textSlide .box {text-shadow:none;}
/* ***********************
--------------------------------------
------------MAIN BORDER COLOR----------
--------------------------------------
*********************** */
#logo a, .recentborder,.item4 .recentborder, .item3 .recentborder,.afterlinehome,.prelinehome, .cartHolder{border-color:<?php echo $data['mainColor']; ?> !important;}


/* ***********************
--------------------------------------
------------BODY COLOR----------
--------------------------------------
*********************** */

.blogpost .link a,.datecomment span,.homesingleleft .tags a,.homesingleleft .postedin a,.blogpostcategory .category a,.blogpostcategory .comments a,
.blogpostcategory a.textlink ,.written a, .blogpostcategory .meta .time a	
{ color:<?php echo $data['body_font']['color']; ?>}
.homeRacent.SP h3 { color:<?php echo $data['heading_font_h3']['color']; ?> !important;}

/* ***********************
--------------------------------------
------------MENU----------
--------------------------------------
*********************** */

.menu li:hover ul {border-bottom: 5px solid <?php echo $data['mainColor']; ?>;}
.menu li ul li a, .item4 h4 a, #portitems2 .category a, .homeRacent .category a, .item3 h4 a, .homeRacent .productF h3.category, .homeRacent .productR h3.category
{	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif !important; }
.menu > li a {	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['menu_font'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif !important; color:#1e1e20 !important;letter-spacing: normal;}
.menu a span{ 	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif  !important; color:#1e1e20 !important;letter-spacing: normal;}

.top-nav a {color:#fff;}
/* ***********************
--------------------------------------
------------BLOG----------
-----------------------------------*/
.blogpostcategory h2 {line-height: 110% !important;}
.wp-pagenavi span.pages {font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif;}
.wp-pagenavi a, .showpostpostcontent h1 a {color:<?php echo $data['heading_font_h2']['color']; ?>;}
.wp-pagenavi a:hover,ul.tabs a:hover, h2.trigger:hover { background-color:<?php echo $data['mainColor']; ?> !important; }
ul.tabs.woo a.current{  background-color:#3A3F43; }
ul.tabs.woo .active a, ul.tabs a.current{  background-color:<?php echo $data['mainColor']; ?>; }
.blogpost .datecomment a, .related h4 a, .content ol.commentlist li .comment-author .fn a, .content ol.commentlist li .reply a {color:<?php echo $data['body_font']['color']; ?>;}
.blogpost .datecomment a:hover, .tags a:hover, .related h4 a:hover, .content ol.commentlist li .comment-author .fn a:hover, .content ol.commentlist li .reply a:hover { color:<?php echo $data['mainColor']; ?>; }
.comment-author .fn a, .homeRacent .productF .recentCart a,.homeRacent .productR .recentCart a{font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['heading_font']['face'])))); ?> !important;}
.image-gallery, .gallery-item { border: 1px dashed <?php echo $data['mainColor']; ?>;}
.blogpostcategory .posted-date p{font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif !important;text-shadow:0 1px 0 <?php echo HexToRGB($data['ShadowColorFont'],$data['ShadowOpacittyColorFont'])?>;}
.pagecontent h1, .pagecontent p, .content ol.commentlist li .reply a, .team .role, .cartWrapper a, .pagecontentContent #breadcrumb {text-shadow:0 1px 0 <?php echo HexToRGB($data['ShadowColorFont'],$data['ShadowOpacittyColorFont'])?>;}
/* ***********************
--------------------------------------
------------Widget----------
-----------------------------------*/
.wttitle a {color:<?php echo $data['heading_font_h4']['color']; ?>;}

.widgetline{<?php echo $bordersidebar; ?>}
.widgett a:hover, .widget_nav_menu ul li a:hover{color:<?php echo $data['mainColor']; ?> !important;}
 .widget_nav_menu ul li a{	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif !important; }
.related h4{	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif !important; }
.widget_search form div {	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif !important;}
.widgett a {	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif !important;}
.widget_tag_cloud a{	font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['body_font']['face'])))); ?>, "Helvetica Neue", Arial, Helvetica, Verdana, sans-serif !important;}


/* ***********************
--------------------------------------
------------BUTTONS WITH SHORTCODES----------
--------------------------------------
*********************** */
.cartWrapper a:hover {color:#fff !important;}
.button_purche_right_top,.button_download_right_top,.button_search_right_top {font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['heading_font']['face'])))); ?> !important;color:<?php echo $data['heading_font_h2']['color']; ?>;text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);}
.button_purche:hover,.button_download:hover,.button_search:hover {color:<?php echo $data['mainColor']; ?> !important;}
.ribbon_center_red a, .ribbon_center_blue a, .ribbon_center_white a, .ribbon_center_yellow a, .ribbon_center_green a {font-family: <?php echo str_replace("%20"," ",str_replace(":300"," ",str_replace(":200"," ",str_replace(":400"," ",$data['heading_font']['face'])))); ?> !important;}
a.button.loading::before, button.button.loading::before, input.button.loading::before {content: "";position: absolute;height: 32px;width: 32px;bottom: 20px;left: 150px;text-indent: 0;background:url(images/loading.gif) no-repeat;}

<?php echo stripText($data['custom_style']) ?>