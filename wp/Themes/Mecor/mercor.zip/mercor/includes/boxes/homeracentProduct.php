<?php

	$args = array( 'post_type' => 'product', 'posts_per_page' => $data['home_recent_products_number'] );
	$pc = new WP_Query( $args );
	
?>

	<script type="text/javascript">


		jQuery(document).ready(function(){	  


		// Slider
		var $slider = jQuery('#productR').bxSlider({
					controls: true,
					displaySlideQty: 1,
					default: 1000,
					easing : 'easeInOutQuint',
					prevText : '',
					nextText : '',
					pager :false
					
				});


		 });
	</script>




		

<div class="homeRacent">
	<div class="titleborder"></div>
	<h2><?php echo stripText($data['translation_recent_pruduct_title']) ?></h2>
	<div id="homeRecent" class="productRH">
	
	<ul id="productR" class="productR">
		<?php
		
		$currentindex = '';
		if ($pc->have_posts()) :
		$count = 1;
		$countitem = 1;

		?>
		<?php  while ($pc->have_posts()) : $pc->the_post();
		global $product;
		if($countitem == 1){
			echo '<li>';}				
		if ( has_post_thumbnail() ){
			$image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full', false);
			$image = $image[0];}
		else
			$image = get_template_directory_uri() .'/images/placeholder-580.png'; 
			if( has_post_format( 'link' , $post->ID))
			add_filter( 'the_excerpt', 'filter_content_link' );		
		if($count != 3){
			echo '<div class="one_third" >';
		}
		else{
			echo '<div class="one_third last" >';
			$count = 0;
		}?>
				<div class="recentimage">
					<div class="image">
						<div class="loading"></div>
						
						<?php 
						if(shortcode_exists( 'yith_wcwl_add_to_wishlist' )){
							echo do_shortcode( '[yith_wcwl_add_to_wishlist]' ); }
						?>
						<a href="<?php echo get_permalink( $post->ID ) ?>" title="<?php the_title() ?>">
							<?php if (has_post_thumbnail( $post->ID )) echo get_image_pmc(294,224,$post->ID); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="'.$woocommerce->get_image_size('shop_catalog_image_width').'px" height="'.$woocommerce->get_image_size('shop_catalog_image_height').'px" />'; ?>
						</a>
					</div>
				</div>
				<div class="recentdescription">
					<?php woocommerce_show_product_sale_flash( $post, $product ); ?>
					<h3><a href="<?php echo get_permalink( $post->ID ) ?>" title="<?php the_title() ?>"><?php the_title() ?></a></h3>
					<h3 class="category"><span class="price"><?php echo $product->get_price_html(); ?></span></h3>	
				</div>
				<div class="recentCart"><?php woocommerce_template_loop_add_to_cart( $post, $product ); ?></div>
			</div>
		<?php 
		$count++;
		
		 if($countitem == 6){ 
			$countitem = 0; ?>
			</li>
		<?php } 
		$countitem++;
		endwhile; endif;
		wp_reset_query(); ?>
		</ul>
	</div>
</div>

<div class="clear"></div>

