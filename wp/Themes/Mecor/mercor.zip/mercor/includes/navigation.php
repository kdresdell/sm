<div class="pagination">
	<div class="alignleft"><?php next_posts_link(__('&laquo; Older Entries','snipe')) ?></div>
	<div class="alignright"><?php previous_posts_link(__('Next Entries &raquo;', 'snipe')) ?></div>
</div>