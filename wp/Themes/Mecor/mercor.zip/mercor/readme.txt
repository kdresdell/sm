You can find documentation at:
ttp://premiumcoding.com/minimalistic-creative-wordpress-theme-mercor/

===============================
3.4
===============================
-fixed accout layout bug
-fexed payment method display bug

/style.css


===============================
3.5
===============================
-fixed shortcode bug
/js/tinymce_shortcodes.php
