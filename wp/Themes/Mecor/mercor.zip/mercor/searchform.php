	<form method="get" id="sidebarsearch" action="<?php get_template_directory_uri(); ?>" >
		<div>
			<input type="text" value="" name="s" id="keyword" />
			<input type="submit" name="submit" id="searchsubmit" value="" /> 
		</div>
	</form>
