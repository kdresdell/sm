	<div class="sidebar">
	
		<?php dynamic_sidebar( 'sidebar_category' ); ?>
	
	</div>

