<?php
/*
Template Name: Full Width Page with Revolution Slider
*/
?>

<?php get_header(); ?>
<div class = "outerpagewrap">	<div class="pagewrap">
		<div class="pagecontent">
			<div class="pagecontentContent">
				<h1><?php the_title();?></h1>
				<p><?php the_breadcrumb(); ?></p>
			</div>
			<div class="homeIcon"><a href="<?php echo home_url(); ?>"></a></div>
		</div>
	</div>
</div>
<?php  $slider = get_post_custom($post->ID); ?><? if(function_exists('putRevSlider')){ ?>	<?php  $slider = get_post_custom($post->ID); ?>	<?php if(isset($slider['slider'])){ ?>	<div id="slider-wrapper">		<div class="loading"></div>			<div id="slider">			<?php putRevSlider("mercor") ?>  		</div>		</div>	<?php } ?><?php } ?>
			
<div id="mainwrap">
	<div id="main" class="clearfix">
	<div class="pad"></div>
		<div class="content fullwidth">
			<div class="postcontent">
				<div class="posttext">
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="usercontent"><?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?></div>					<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
					<?php endwhile; endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
