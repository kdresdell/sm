<?php
/*
Template Name: Home with Revolution Slider 
*/
?>

<?php get_header(); ?>
<? if(function_exists('putRevSlider')){ ?>
	<?php  $slider = get_post_custom($post->ID); ?>

	<div id="slider-wrapper">
		<div class="loading"></div>	
		<div id="slider">
			<?php putRevSlider("mercor") ?>  
		</div>	
	</div>
<?php } ?>

		
<div id="mainwrap" class="homewrap">

<div id="main" class="clearfix">

	
	<div class="clear"></div>
	
	<div class="home-boxes-revolution">
	<?php if(isset($data['box_status'])) { ?>

		<?php include('includes/boxes/homebox.php'); ?>
		
	<?php }?>
	</div>
	
	<?php if(isset($data['infotext_status'])) { ?>
		<div class="infotextwrap">
			<div class="infotext">
				<h2><?php echo  stripText($data['infotext'])?></h2>
			</div>
		</div>
	<?php }?>
	
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
	
	<div class="usercontent homeuser"><?php the_content(); ?></div>
	
	
	<?php endwhile; endif; ?>

	<div class="clear"></div>	
	
	<?php if(isset($data['racent_status_productF']) && function_exists( 'is_woocommerce' )) { ?>
		<?php include('includes/boxes/homeracentProductF.php'); ?>
	
	<?php }?>	
	
	<?php if(isset($data['racent_status_product']) && function_exists( 'is_woocommerce' )) { ?>
		<?php include('includes/boxes/homeracentProduct.php'); ?>
	
	<?php }?>
	
	<?php if(isset($data['racent_status_port'])) { ?>
		<?php include('includes/boxes/homeracentPort.php'); ?>
	
	<?php }?>		
	
	
	<?php if(isset($data['racent_status'])) { ?>
		<?php include('includes/boxes/homeracentPost.php'); ?>
	
	<?php }?>	

	<?php if(isset($data['showadvertise'])) { ?>

		<?php include('includes/boxes/advertise.php'); ?>
		
	<?php }?>		
	<div class="clear"> </div>	

</div>
</div>


<?php get_footer(); ?>