<?php

get_header('shop'); 
global $data;?>

	<div class = "outerpagewrap">

		<div class="pagewrap">

			<div class="pagecontent">

				<div class="pagecontentContent">
				
					<h1>
						<?php if ( is_search() ) : ?>
							<?php
								printf( __( 'Search Results: &ldquo;%s&rdquo;', 'woocommerce' ), get_search_query() );
								if ( get_query_var( 'paged' ) )
									printf( __( '&nbsp;&ndash; Page %s', 'woocommerce' ), get_query_var( 'paged' ) );
							?>
						<?php elseif ( is_tax() ) : ?>
							<?php echo single_term_title( "", false ); ?>
						<?php else : ?>
							<?php
								$shop_page = get_post( woocommerce_get_page_id( 'shop' ) );

								echo apply_filters( 'the_title', ( $shop_page_title = get_option( 'woocommerce_shop_page_title' ) ) ? $shop_page_title : $shop_page->post_title );
							?>
						<?php endif; ?>
						
					</h1>
					<p><?php woocommerce_breadcrumb(); ?></p>
				</div>

				<div class="homeIcon"><a href="<?php echo home_url(); ?>"></a></div>

			</div>



		</div>

	</div>					
	<div id="mainwrap" class="homewrap">

		<div id="main" class="clearfix">

		<?php do_action( 'woocommerce_archive_description' ); ?>

		<?php if ( is_tax() ) : ?>
			<?php do_action( 'woocommerce_taxonomy_archive_description' ); ?>
		<?php elseif ( ! empty( $shop_page ) && is_object( $shop_page ) ) : ?>
			<?php do_action( 'woocommerce_product_archive_description', $shop_page ); ?>
		<?php endif; ?>
		
		<?php 


			


		?>

		<?php if ( have_posts() ) : ?>

			<?php
			/**
			* Sorting
			*/
			?>
			<div class="categorytopbarWraper">
				<?php get_template_part('woocommerce/loop/sorting'); ?>
			<div class="categorytopbar">

				<?php dynamic_sidebar( 'sidebar_category_top' ); ?>

			</div>
			</div>
			
			<div class="homeRacent">
			<div class="wocategoryFull">
				<div class="productR">
				
					<?php woocommerce_product_subcategories(); ?>
					
					
					<?php
					$currentindex = '';
					$count = 1;
					$countitem = 1;
		
					

					while ( have_posts() ) : the_post(); global $product;

				
					if($count != 3){
						echo '<div class="one_third" >';
					}
					else{
						echo '<div class="one_third last" >';
						$count = 0;
					}?>
							<div class="recentimage">
								<div class="image">
									<div class="loading"></div>
									<?php 
									if(shortcode_exists( 'yith_wcwl_add_to_wishlist' )){
										echo do_shortcode( '[yith_wcwl_add_to_wishlist]' ); }
									?>
									<a href="<?php echo get_permalink( get_the_ID() ) ?>" title="<?php the_title() ?>">									
										<?php if (has_post_thumbnail( get_the_ID() )) echo get_image_pmc(294,224,get_the_ID()); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="'.$woocommerce->get_image_size('shop_catalog_image_width').'px" height="'.$woocommerce->get_image_size('shop_catalog_image_height').'px" />'; ?>
									</a>
								</div>
							</div>
						
							<div class="recentdescription">
								<?php woocommerce_show_product_sale_flash( get_the_ID(), $product ); ?>
								<h3><a href="<?php echo get_permalink( get_the_ID() ) ?>" title="<?php the_title() ?>"><?php echo substr(the_title(' ', ' ', false),0,40) ?></a></h3>
								<h3 class="category"><span class="price"><?php echo $product->get_price_html(); ?></span></h3>	
							</div>
							<div class="recentCart"><?php woocommerce_template_loop_add_to_cart( get_the_ID(), $product ); ?></div>
						
						</div>
					<?php 
					$count++;
					
					$countitem++;

					 endwhile; // end of the loop. ?>

				</div>
				<?php
				
					include(TEMPLATEPATH .'/includes/wp-pagenavi.php');
					if(function_exists('wp_pagenavi')) { wp_pagenavi(); }
				?>
				<?php do_action('woocommerce_after_shop_loop'); ?>
			</div>
		<?php else : ?>

			<?php if ( ! woocommerce_product_subcategories( array( 'before' => '<ul class="products">', 'after' => '</ul>' ) ) ) : ?>

				<p><?php _e( 'No products found which match your selection.', 'woocommerce' ); ?></p>

			<?php endif; ?>
		
		<?php endif; ?>


		</div>
		</div>
	</div>

<?php get_footer('shop'); ?>