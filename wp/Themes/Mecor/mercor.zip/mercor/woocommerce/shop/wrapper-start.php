<?php
/**
 * Content wrappers
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     99.99
 */
 ?>

<div id="mainwrap" class="homewrap">

	<div id="main" class="clearfix">