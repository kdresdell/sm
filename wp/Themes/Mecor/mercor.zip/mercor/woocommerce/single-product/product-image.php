<?php
/**
 * Single Product Image
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     99.99
 */

global $post, $woocommerce, $data,$product;

?>

<div class="imagesSPAll">

	<div class="images imagesSP">

	<script type="text/javascript">
	jQuery(document).ready(function($){

			$('#slider').anythingSlider({
			hashTags : false,
			expand		: true,
			autoPlay	: true,
			resizeContents  : false,
			pauseOnHover    : true,
			buildArrows     : false,
			buildNavigation : false,
			delay		: <?php echo $data['pausetime'] ?>,
			resumeDelay	: 0,
			animationTime	: <?php echo $data['anispeed'] ?>,
			delayBeforeAnimate:0,	
			easing : 'easeInOutQuint',
			 onShowStart       : function(e, slider) {	$('.nextbutton').fadeIn();
				$('.prevbutton').fadeIn();
				$('.activePage img').addClass('zoom');
				<?php if(isset($data['woo_zoom'])){ ?>
				$(".zoom").elevateZoom({
				  zoomType				: "lens",
				  lensShape : "window",
				  lensSize    : 200
				  
				   });	
				<?php }?>			

				},
			onSlideBegin    : function(e, slider) {
					$('.nextbutton').fadeOut();
					$('.prevbutton').fadeOut();
					var image = $('.zoom');
					$.removeData(image, 'elevateZoom');//remove zoom instance from image
					$('img').removeClass('zoom');
					$('.zoomContainer').remove();// remove zoom container from DOM
			
			},
			onSlideComplete    : function(slider) {
				$('.nextbutton').fadeIn();
				$('.prevbutton').fadeIn();
				$('.activePage img').addClass('zoom');
				<?php if(isset($data['woo_zoom'])){ ?>
				$(".zoom").elevateZoom({
				  zoomType				: "lens",
				  lensShape : "window",
				  lensSize    : 200
				  
				   });	
				<?php }?>
			}		
			})

			
			$('.blogsingleimage').hover(function() {
			$(".slideforward").stop(true, true).fadeIn();
			$(".slidebackward").stop(true, true).fadeIn();
			}, function() {
			$(".slideforward").fadeOut();
			$(".slidebackward").fadeOut();
			});
			$(".pauseButton").toggle(function(){
			$(this).attr("class", "playButton");
			$('#slider').data('AnythingSlider').startStop(false); // stops the slideshow
			},function(){
			$(this).attr("class", "pauseButton");
			$('#slider').data('AnythingSlider').startStop(true);  // start the slideshow
			});
			$(".slideforward").click(function(){
			$('#slider').data('AnythingSlider').goForward();
			});
			$(".slidebackward").click(function(){
			$('#slider').data('AnythingSlider').goBack();
			});  
		});
		
		
		
	</script>		
		<?php
			$attachments = $product->get_gallery_attachment_ids();

			if ($attachments) {?>
				<div class="loading"></div>
				<div id="slider" class="slider product">
					
						<?php 
							$i = 0;
							$zoom = '';
							if(count($attachments) == 1){
								$zoom = 'zoom';
							}

							foreach ($attachments as $id) {
								//echo apply_filters('the_title', $attachment->post_title);
								$image =  wp_get_attachment_image_src( $id, 'full' ); ?>	
									<div>
										<a href = "<?php echo $image[0] ?>" title="<?php the_title(); ?>" rel="prettyPhoto" ><img class="check <?php echo $zoom ?>" src="<?php echo get_template_directory_uri() ?>/js/timthumb.php?src=<?php echo $image[0] ?>&amp;w=470&amp;h=345" data-zoom-image="<?php echo $image[0] ?>"/></a>				
												
									</div>
									
									<?php 
									$i++;
									} ?>
			
					
				</div>
				<?php if($i > 1) { ?>
				<div class="navigationSP">
					<div class="prevbutton slidebackward port"></div>
					<div class="nextbutton slideforward port"></div>
				</div>	
				<?php } ?>
				<?php } else if ( has_post_thumbnail() ) { 
					$large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); ?>
					<a href = "<?php echo $large_image_url[0] ?>" title="<?php echo get_the_title($id) ?>" rel ="prettyPhoto" ><img class="check" src="<?php echo get_template_directory_uri() ?>/js/timthumb.php?src=<?php echo $large_image_url[0] ?>&amp;w=470&amp;h=345" /></a>				
					<?php
				} else { ?>
				
				<img src="<?php echo get_template_directory_uri() ?>/js/timthumb.php?src=<?php echo woocommerce_placeholder_img_src(); ?>&amp;w=470&amp;h=335" alt="Placeholder" />
				
				<?php } ?>

		</div>
		<div class="thumbnails"><?php

			if ($attachments) {

				foreach ( $attachments as $id ) {
				
					$image =  wp_get_attachment_image_src( $id, 'full' ); 
					$image = get_template_directory_uri() .'/js/timthumb.php?src='.  $image[0] .'&amp;w=90&amp;h=90';
					
					printf( '<a href="%s" title="%s" rel="prettyPhoto[product-gallery]" class="thumbSP"><img src="%s" ></a>', wp_get_attachment_url( $id ), get_the_title($id), $image );

				}

			}
		?></div>
</div>	