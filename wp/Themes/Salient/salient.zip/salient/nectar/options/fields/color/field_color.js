jQuery(document).ready(function ($) {
    $('input.popup-colorpicker').wpColorPicker({
    	palettes: ['#27CCC0', '#f6653c', '#2ac4ea', '#ae81f9', '#FF4629', '#78cd6e']
    });
});
