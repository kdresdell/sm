<?php 

$google_fonts = array (
  0 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'ABeeZee',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  1 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Abel',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  2 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Abril Fatface',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  3 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Aclonica',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  4 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Acme',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  5 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Actor',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  6 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Adamina',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  7 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Advent Pro',
    'variants' => 
    array (
      0 => '100',
      1 => '200',
      2 => '300',
      3 => 'regular',
      4 => '500',
      5 => '600',
      6 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
    ),
  ),
  8 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Aguafina Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  9 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Akronim',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  10 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Aladin',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  11 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Aldrich',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  12 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alegreya',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  13 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alegreya SC',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  14 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alegreya Sans',
    'variants' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '500',
      7 => '500italic',
      8 => '700',
      9 => '700italic',
      10 => '800',
      11 => '800italic',
      12 => '900',
      13 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  15 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alegreya Sans SC',
    'variants' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '500',
      7 => '500italic',
      8 => '700',
      9 => '700italic',
      10 => '800',
      11 => '800italic',
      12 => '900',
      13 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  16 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alex Brush',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  17 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alfa Slab One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  18 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alice',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  19 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alike',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  20 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Alike Angular',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  21 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Allan',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  22 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Allerta',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  23 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Allerta Stencil',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  24 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Allura',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  25 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Almendra',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  26 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Almendra Display',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  27 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Almendra SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  28 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Amarante',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  29 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Amaranth',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  30 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Amatic SC',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  31 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Amethysta',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  32 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Anaheim',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  33 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Andada',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  34 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Andika',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  35 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Angkor',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  36 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Annie Use Your Telescope',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  37 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Anonymous Pro',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
      5 => 'greek-ext',
    ),
  ),
  38 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Antic',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  39 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Antic Didone',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  40 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Antic Slab',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  41 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Anton',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  42 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Arapey',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  43 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Arbutus',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  44 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Arbutus Slab',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  45 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Architects Daughter',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  46 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Archivo Black',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  47 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Archivo Narrow',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  48 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Arimo',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'vietnamese',
      3 => 'latin-ext',
      4 => 'cyrillic',
      5 => 'latin',
      6 => 'greek-ext',
    ),
  ),
  49 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Arizonia',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  50 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Armata',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  51 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Artifika',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  52 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Arvo',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  53 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Asap',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  54 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Asset',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  55 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Astloch',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  56 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Asul',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  57 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Atomic Age',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  58 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Aubrey',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  59 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Audiowide',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  60 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Autour One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  61 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Average',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  62 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Average Sans',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  63 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Averia Gruesa Libre',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  64 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Averia Libre',
    'variants' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  65 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Averia Sans Libre',
    'variants' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  66 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Averia Serif Libre',
    'variants' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  67 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bad Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic',
      1 => 'latin',
    ),
  ),
  68 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Balthazar',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  69 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bangers',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  70 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Basic',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  71 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Battambang',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  72 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Baumans',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  73 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bayon',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  74 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Belgrano',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  75 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Belleza',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  76 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'BenchNine',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  77 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bentham',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  78 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Berkshire Swash',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  79 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bevan',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  80 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bigelow Rules',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  81 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bigshot One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  82 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bilbo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  83 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bilbo Swash Caps',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  84 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bitter',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  85 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Black Ops One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  86 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bokor',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  87 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bonbon',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  88 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Boogaloo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  89 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bowlby One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  90 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bowlby One SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  91 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Brawler',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  92 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bree Serif',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  93 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bubblegum Sans',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  94 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Bubbler One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  95 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Buda',
    'variants' => 
    array (
      0 => '300',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  96 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Buenard',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  97 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Butcherman',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  98 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Butterfly Kids',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  99 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cabin',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '500',
      3 => '500italic',
      4 => '600',
      5 => '600italic',
      6 => '700',
      7 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  100 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cabin Condensed',
    'variants' => 
    array (
      0 => 'regular',
      1 => '500',
      2 => '600',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  101 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cabin Sketch',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  102 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Caesar Dressing',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  103 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cagliostro',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  104 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Calligraffitti',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  105 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cambo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  106 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Candal',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  107 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cantarell',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  108 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cantata One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  109 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cantora One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  110 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Capriola',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  111 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cardo',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'greek-ext',
    ),
  ),
  112 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Carme',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  113 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Carrois Gothic',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  114 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Carrois Gothic SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  115 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Carter One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  116 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Caudex',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'greek-ext',
    ),
  ),
  117 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cedarville Cursive',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  118 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ceviche One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  119 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Changa One',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  120 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Chango',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  121 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Chau Philomene One',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  122 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Chela One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  123 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Chelsea Market',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  124 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Chenla',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  125 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cherry Cream Soda',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  126 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cherry Swash',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  127 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Chewy',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  128 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Chicle',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  129 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Chivo',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '900',
      3 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  130 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cinzel',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  131 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cinzel Decorative',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  132 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Clicker Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  133 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Coda',
    'variants' => 
    array (
      0 => 'regular',
      1 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  134 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Coda Caption',
    'variants' => 
    array (
      0 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  135 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Codystar',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  136 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Combo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  137 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Comfortaa',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
    ),
  ),
  138 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Coming Soon',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  139 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Concert One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  140 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Condiment',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  141 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Content',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  142 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Contrail One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  143 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Convergence',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  144 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cookie',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  145 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Copse',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  146 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Corben',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  147 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Courgette',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  148 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cousine',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  149 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Coustard',
    'variants' => 
    array (
      0 => 'regular',
      1 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  150 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Covered By Your Grace',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  151 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Crafty Girls',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  152 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Creepster',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  153 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Crete Round',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  154 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Crimson Text',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '600',
      3 => '600italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  155 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Croissant One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  156 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Crushed',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  157 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cuprum',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  158 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cutive',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  159 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Cutive Mono',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  160 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Damion',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  161 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Dancing Script',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  162 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Dangrek',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  163 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Dawning of a New Day',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  164 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Days One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  165 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Delius',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  166 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Delius Swash Caps',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  167 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Delius Unicase',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  168 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Della Respira',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  169 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Denk One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  170 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Devonshire',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  171 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Didact Gothic',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
      5 => 'greek-ext',
    ),
  ),
  172 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Diplomata',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  173 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Diplomata SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  174 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Domine',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  175 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Donegal One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  176 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Doppio One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  177 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Dorsa',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  178 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Dosis',
    'variants' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => '500',
      4 => '600',
      5 => '700',
      6 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  179 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Dr Sugiyama',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  180 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Droid Sans',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  181 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Droid Sans Mono',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  182 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Droid Serif',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  183 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Duru Sans',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  184 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Dynalight',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  185 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'EB Garamond',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'vietnamese',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
    ),
  ),
  186 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Eagle Lake',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  187 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Eater',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  188 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Economica',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  189 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Electrolize',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  190 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Elsie',
    'variants' => 
    array (
      0 => 'regular',
      1 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  191 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Elsie Swash Caps',
    'variants' => 
    array (
      0 => 'regular',
      1 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  192 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Emblema One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  193 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Emilys Candy',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  194 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Engagement',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  195 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Englebert',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  196 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Enriqueta',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  197 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Erica One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  198 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Esteban',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  199 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Euphoria Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  200 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ewert',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  201 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Exo',
    'variants' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '200',
      3 => '200italic',
      4 => '300',
      5 => '300italic',
      6 => 'regular',
      7 => 'italic',
      8 => '500',
      9 => '500italic',
      10 => '600',
      11 => '600italic',
      12 => '700',
      13 => '700italic',
      14 => '800',
      15 => '800italic',
      16 => '900',
      17 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  202 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Exo 2',
    'variants' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '200',
      3 => '200italic',
      4 => '300',
      5 => '300italic',
      6 => 'regular',
      7 => 'italic',
      8 => '500',
      9 => '500italic',
      10 => '600',
      11 => '600italic',
      12 => '700',
      13 => '700italic',
      14 => '800',
      15 => '800italic',
      16 => '900',
      17 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  203 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Expletus Sans',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '500',
      3 => '500italic',
      4 => '600',
      5 => '600italic',
      6 => '700',
      7 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  204 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fanwood Text',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  205 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fascinate',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  206 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fascinate Inline',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  207 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Faster One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  208 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fasthand',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  209 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Federant',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  210 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Federo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  211 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Felipa',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  212 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fenix',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  213 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Finger Paint',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  214 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fjalla One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  215 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fjord One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  216 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Flamenco',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  217 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Flavors',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  218 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fondamento',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  219 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fontdiner Swanky',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  220 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Forum',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  221 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Francois One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  222 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Freckle Face',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  223 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fredericka the Great',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  224 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fredoka One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  225 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Freehand',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  226 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fresca',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  227 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Frijole',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  228 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fruktur',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  229 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fugaz One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  230 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'GFS Didot',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'greek',
    ),
  ),
  231 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'GFS Neohellenic',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
    ),
  ),
  232 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gabriela',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  233 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gafata',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  234 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Galdeano',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  235 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Galindo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  236 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gentium Basic',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  237 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gentium Book Basic',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  238 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Geo',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  239 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Geostar',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  240 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Geostar Fill',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  241 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Germania One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  242 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gilda Display',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  243 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Give You Glory',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  244 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Glass Antiqua',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  245 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Glegoo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  246 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gloria Hallelujah',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  247 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Goblin One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  248 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gochi Hand',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  249 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gorditas',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  250 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Goudy Bookletter 1911',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  251 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Graduate',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  252 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Grand Hotel',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  253 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gravitas One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  254 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Great Vibes',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  255 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Griffy',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  256 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gruppo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  257 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Gudea',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  258 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Habibi',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  259 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Hammersmith One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  260 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Hanalei',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  261 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Hanalei Fill',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  262 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Handlee',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  263 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Hanuman',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  264 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Happy Monkey',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  265 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Headland One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  266 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Henny Penny',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  267 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Herr Von Muellerhoff',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  268 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Holtwood One SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  269 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Homemade Apple',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  270 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Homenaje',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  271 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell DW Pica',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  272 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell DW Pica SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  273 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell Double Pica',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  274 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell Double Pica SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  275 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell English',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  276 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell English SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  277 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell French Canon',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  278 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell French Canon SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  279 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell Great Primer',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  280 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'IM Fell Great Primer SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  281 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Iceberg',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  282 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Iceland',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  283 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Imprima',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  284 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Inconsolata',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  285 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Inder',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  286 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Indie Flower',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  287 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Inika',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  288 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Irish Grover',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  289 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Istok Web',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  290 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Italiana',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  291 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Italianno',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  292 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Jacques Francois',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  293 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Jacques Francois Shadow',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  294 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Jim Nightshade',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  295 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Jockey One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  296 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Jolly Lodger',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  297 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Josefin Sans',
    'variants' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '600',
      7 => '600italic',
      8 => '700',
      9 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  298 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Josefin Slab',
    'variants' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '600',
      7 => '600italic',
      8 => '700',
      9 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  299 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Joti One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  300 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Judson',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  301 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Julee',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  302 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Julius Sans One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  303 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Junge',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  304 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Jura',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
      5 => 'greek-ext',
    ),
  ),
  305 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Just Another Hand',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  306 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Just Me Again Down Here',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  307 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kameron',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  308 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Karla',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  309 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kaushan Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  310 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kavoon',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  311 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Keania One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  312 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kelly Slab',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  313 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kenia',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  314 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Khmer',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  315 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kite One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  316 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Knewave',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  317 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kotta One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  318 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Koulen',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  319 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kranky',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  320 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kreon',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  321 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Kristi',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  322 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Krona One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  323 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'La Belle Aurore',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  324 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lancelot',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  325 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lato',
    'variants' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '700',
      7 => '700italic',
      8 => '900',
      9 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  326 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'League Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  327 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Leckerli One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  328 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ledger',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  329 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lekton',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  330 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lemon',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  331 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Libre Baskerville',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  332 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Life Savers',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  333 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lilita One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  334 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Limelight',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  335 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Linden Hill',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  336 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lobster',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  337 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lobster Two',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  338 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Londrina Outline',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  339 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Londrina Shadow',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  340 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Londrina Sketch',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  341 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Londrina Solid',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  342 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lora',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  343 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Love Ya Like A Sister',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  344 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Loved by the King',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  345 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lovers Quarrel',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  346 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Luckiest Guy',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  347 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lusitana',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  348 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Lustria',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  349 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Macondo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  350 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Macondo Swash Caps',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  351 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Magra',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  352 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Maiden Orange',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  353 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mako',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  354 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Marcellus',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  355 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Marcellus SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  356 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Marck Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  357 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Margarine',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  358 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Marko One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  359 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Marmelad',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  360 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Marvel',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  361 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mate',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  362 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mate SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  363 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Maven Pro',
    'variants' => 
    array (
      0 => 'regular',
      1 => '500',
      2 => '700',
      3 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  364 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'McLaren',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  365 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Meddon',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  366 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'MedievalSharp',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  367 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Medula One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  368 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Megrim',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  369 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Meie Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  370 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Merienda',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  371 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Merienda One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  372 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Merriweather',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
      3 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  373 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Merriweather Sans',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
      3 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  374 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Metal',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  375 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Metal Mania',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  376 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Metamorphous',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  377 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Metrophobic',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  378 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Michroma',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  379 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Milonga',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  380 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Miltonian',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  381 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Miltonian Tattoo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  382 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Miniver',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  383 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Miss Fajardose',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  384 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Modern Antiqua',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  385 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Molengo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  386 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Molle',
    'variants' => 
    array (
      0 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  387 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Monda',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  388 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Monofett',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  389 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Monoton',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  390 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Monsieur La Doulaise',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  391 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Montaga',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  392 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Montez',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  393 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Montserrat',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  394 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Montserrat Alternates',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  395 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Montserrat Subrayada',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  396 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Moul',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  397 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Moulpali',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  398 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mountains of Christmas',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  399 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mouse Memoirs',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  400 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mr Bedfort',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  401 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mr Dafoe',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  402 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mr De Haviland',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  403 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mrs Saint Delafield',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  404 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mrs Sheppards',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  405 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Muli',
    'variants' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  406 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Mystery Quest',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  407 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Neucha',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic',
      1 => 'latin',
    ),
  ),
  408 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Neuton',
    'variants' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  409 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'New Rocker',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  410 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'News Cycle',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  411 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Niconne',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  412 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nixie One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  413 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nobile',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  414 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nokora',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  415 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Norican',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  416 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nosifer',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  417 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nothing You Could Do',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  418 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Noticia Text',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'vietnamese',
      1 => 'latin-ext',
      2 => 'latin',
    ),
  ),
  419 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Noto Sans',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'vietnamese',
      3 => 'latin-ext',
      4 => 'cyrillic',
      5 => 'latin',
      6 => 'greek-ext',
    ),
  ),
  420 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nova Cut',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  421 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nova Flat',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  422 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nova Mono',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin',
    ),
  ),
  423 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nova Oval',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  424 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nova Round',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  425 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nova Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  426 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nova Slim',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  427 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nova Square',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  428 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Numans',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  429 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Nunito',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  430 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Odor Mean Chey',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  431 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Offside',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  432 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Old Standard TT',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  433 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Oldenburg',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  434 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Oleo Script',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  435 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Oleo Script Swash Caps',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  436 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Open Sans',
    'variants' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '600',
      5 => '600italic',
      6 => '700',
      7 => '700italic',
      8 => '800',
      9 => '800italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'vietnamese',
      3 => 'latin-ext',
      4 => 'cyrillic',
      5 => 'latin',
      6 => 'greek-ext',
    ),
  ),
  437 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Open Sans Condensed',
    'variants' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'vietnamese',
      3 => 'latin-ext',
      4 => 'cyrillic',
      5 => 'latin',
      6 => 'greek-ext',
    ),
  ),
  438 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Oranienbaum',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  439 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Orbitron',
    'variants' => 
    array (
      0 => 'regular',
      1 => '500',
      2 => '700',
      3 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  440 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Oregano',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  441 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Orienta',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  442 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Original Surfer',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  443 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Oswald',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  444 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Over the Rainbow',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  445 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Overlock',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  446 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Overlock SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  447 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ovo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  448 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Oxygen',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  449 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Oxygen Mono',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  450 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'PT Mono',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  451 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'PT Sans',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  452 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'PT Sans Caption',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  453 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'PT Sans Narrow',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  454 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'PT Serif',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic',
      1 => 'latin',
    ),
  ),
  455 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'PT Serif Caption',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic',
      1 => 'latin',
    ),
  ),
  456 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Pacifico',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  457 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Paprika',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  458 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Parisienne',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  459 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Passero One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  460 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Passion One',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  461 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Patrick Hand',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'vietnamese',
      1 => 'latin-ext',
      2 => 'latin',
    ),
  ),
  462 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Patrick Hand SC',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'vietnamese',
      1 => 'latin-ext',
      2 => 'latin',
    ),
  ),
  463 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Patua One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  464 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Paytone One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  465 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Peralta',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  466 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Permanent Marker',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  467 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Petit Formal Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  468 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Petrona',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  469 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Philosopher',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic',
      1 => 'latin',
    ),
  ),
  470 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Piedra',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  471 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Pinyon Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  472 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Pirata One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  473 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Plaster',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  474 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Play',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
      5 => 'greek-ext',
    ),
  ),
  475 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Playball',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  476 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Playfair Display',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  477 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Playfair Display SC',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  478 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Podkova',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  479 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Poiret One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  480 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Poller One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  481 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Poly',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  482 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Pompiere',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  483 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Pontano Sans',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  484 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Port Lligat Sans',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  485 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Port Lligat Slab',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  486 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Prata',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  487 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Preahvihear',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  488 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Press Start 2P',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  489 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Princess Sofia',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  490 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Prociono',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  491 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Prosto One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  492 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Puritan',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  493 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Purple Purse',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  494 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Quando',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  495 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Quantico',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  496 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Quattrocento',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  497 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Quattrocento Sans',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  498 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Questrial',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  499 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Quicksand',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  500 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Quintessential',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  501 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Qwigley',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  502 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Racing Sans One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  503 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Radley',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  504 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Raleway',
    'variants' => 
    array (
      0 => '100',
      1 => '200',
      2 => '300',
      3 => 'regular',
      4 => '500',
      5 => '600',
      6 => '700',
      7 => '800',
      8 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  505 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Raleway Dots',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  506 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rambla',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  507 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rammetto One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  508 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ranchers',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  509 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rancho',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  510 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rationale',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  511 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Redressed',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  512 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Reenie Beanie',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  513 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Revalia',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  514 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ribeye',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  515 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ribeye Marrow',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  516 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Righteous',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  517 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Risque',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  518 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Roboto',
    'variants' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '500',
      7 => '500italic',
      8 => '700',
      9 => '700italic',
      10 => '900',
      11 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'vietnamese',
      3 => 'latin-ext',
      4 => 'cyrillic',
      5 => 'latin',
      6 => 'greek-ext',
    ),
  ),
  519 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Roboto Condensed',
    'variants' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'vietnamese',
      3 => 'latin-ext',
      4 => 'cyrillic',
      5 => 'latin',
      6 => 'greek-ext',
    ),
  ),
  520 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Roboto Slab',
    'variants' => 
    array (
      0 => '100',
      1 => '300',
      2 => 'regular',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'vietnamese',
      3 => 'latin-ext',
      4 => 'cyrillic',
      5 => 'latin',
      6 => 'greek-ext',
    ),
  ),
  521 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rochester',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  522 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rock Salt',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  523 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rokkitt',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  524 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Romanesco',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  525 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ropa Sans',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  526 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rosario',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  527 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rosarivo',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  528 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rouge Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  529 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ruda',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  530 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rufina',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  531 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ruge Boogie',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  532 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ruluko',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  533 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rum Raisin',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  534 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ruslan Display',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  535 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Russo One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  536 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ruthie',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  537 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Rye',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  538 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sacramento',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  539 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sail',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  540 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Salsa',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  541 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sanchez',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  542 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sancreek',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  543 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sansita One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  544 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sarina',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  545 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Satisfy',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  546 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Scada',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  547 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Schoolbell',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  548 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Seaweed Script',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  549 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sevillana',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  550 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Seymour One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  551 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Shadows Into Light',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  552 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Shadows Into Light Two',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  553 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Shanti',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  554 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Share',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  555 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Share Tech',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  556 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Share Tech Mono',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  557 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Shojumaru',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  558 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Short Stack',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  559 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Siemreap',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  560 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sigmar One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  561 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Signika',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '600',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  562 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Signika Negative',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '600',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  563 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Simonetta',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '900',
      3 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  564 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sintony',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  565 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sirin Stencil',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  566 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Six Caps',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  567 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Skranji',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  568 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Slackey',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  569 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Smokum',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  570 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Smythe',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  571 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sniglet',
    'variants' => 
    array (
      0 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  572 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Snippet',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  573 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Snowburst One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  574 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sofadi One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  575 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sofia',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  576 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sonsie One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  577 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sorts Mill Goudy',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  578 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Source Code Pro',
    'variants' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => '500',
      4 => '600',
      5 => '700',
      6 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  579 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Source Sans Pro',
    'variants' => 
    array (
      0 => '200',
      1 => '200italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '600',
      7 => '600italic',
      8 => '700',
      9 => '700italic',
      10 => '900',
      11 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  580 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Special Elite',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  581 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Spicy Rice',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  582 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Spinnaker',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  583 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Spirax',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  584 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Squada One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  585 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Stalemate',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  586 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Stalinist One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  587 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Stardos Stencil',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  588 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Stint Ultra Condensed',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  589 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Stint Ultra Expanded',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  590 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Stoke',
    'variants' => 
    array (
      0 => '300',
      1 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  591 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Strait',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  592 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sue Ellen Francisco',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  593 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Sunshiney',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  594 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Supermercado One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  595 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Suwannaphum',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  596 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Swanky and Moo Moo',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  597 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Syncopate',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  598 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Tangerine',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  599 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Taprom',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  600 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Tauri',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  601 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Telex',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  602 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Tenor Sans',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'latin-ext',
      2 => 'cyrillic',
      3 => 'latin',
    ),
  ),
  603 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Text Me One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  604 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'The Girl Next Door',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  605 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Tienne',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  606 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Tinos',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  607 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Titan One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  608 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Titillium Web',
    'variants' => 
    array (
      0 => '200',
      1 => '200italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '600',
      7 => '600italic',
      8 => '700',
      9 => '700italic',
      10 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  609 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Trade Winds',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  610 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Trocchi',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  611 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Trochut',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  612 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Trykker',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  613 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Tulpen One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  614 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ubuntu',
    'variants' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '500',
      5 => '500italic',
      6 => '700',
      7 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
      5 => 'greek-ext',
    ),
  ),
  615 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ubuntu Condensed',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
      5 => 'greek-ext',
    ),
  ),
  616 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ubuntu Mono',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'cyrillic-ext',
      1 => 'greek',
      2 => 'latin-ext',
      3 => 'cyrillic',
      4 => 'latin',
      5 => 'greek-ext',
    ),
  ),
  617 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Ultra',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  618 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Uncial Antiqua',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  619 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Underdog',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  620 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Unica One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  621 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'UnifrakturCook',
    'variants' => 
    array (
      0 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  622 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'UnifrakturMaguntia',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  623 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Unkempt',
    'variants' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  624 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Unlock',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  625 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Unna',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  626 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'VT323',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  627 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Vampiro One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  628 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Varela',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  629 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Varela Round',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  630 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Vast Shadow',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  631 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Vibur',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  632 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Vidaloka',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  633 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Viga',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  634 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Voces',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  635 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Volkhov',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  636 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Vollkorn',
    'variants' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  637 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Voltaire',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  638 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Waiting for the Sunrise',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  639 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Wallpoet',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  640 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Walter Turncoat',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  641 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Warnes',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  642 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Wellfleet',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  643 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Wendy One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  644 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Wire One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  645 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Yanone Kaffeesatz',
    'variants' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  646 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Yellowtail',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  647 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Yeseva One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'cyrillic',
      2 => 'latin',
    ),
  ),
  648 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Yesteryear',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  649 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Zeyada',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  650 => 
  array (
    'kind' => 'webfonts#webfont',
    'family' => 'Fauna One',
    'variants' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
);


function options_typography_get_os_fonts() {
    // OS Font Defaults
    $os_faces = array(
        'Arial, sans-serif' => 'Arial',
        'Cambria, Georgia, serif' => 'Cambria',
        'Copse, sans-serif' => 'Copse',
        'Garamond, Times New Roman, Times, serif' => 'Garamond',
        'Georgia, serif' => 'Georgia',
        'Helvetica, sans-serif' => 'Sans Serif',
        'Tahoma, Geneva, sans-serif' => 'Tahoma',
        'Lovelo, sans-serif' => 'Lovelo'
    );
    return $os_faces;
}

function options_typography_get_google_fonts() {
	global $google_fonts;
	
	$google_fonts_object = $google_fonts;

	$google_faces = array();
	foreach($google_fonts_object as $obj => $props) {
		$google_faces[$props['family']] =  $props['family']; 
	}

		
    // Google Font Defaults
   // $google_faces = array(
   //     'Arvo, serif' => 'Arvo',
   //     'Copse, sans-serif' => 'Copse',
   //     'Droid Sans, sans-serif' => 'Droid Sans',
   //     'Droid Serif, serif' => 'Droid Serif',
   //     'Lobster, cursive' => 'Lobster',
   //     'Nobile, sans-serif' => 'Nobile',
   //     'Open Sans, sans-serif' => 'Open Sans',
    //    'Open Sans Condensed, sans-serif' => 'Open Sans Condensed',
   //     'Oswald, sans-serif' => 'Oswald',
   //     'Pacifico, cursive' => 'Pacifico',
   //     'Rokkitt, serif' => 'Rokkit',
   //     'PT Sans, sans-serif' => 'PT Sans',
   //     'Quattrocento, serif' => 'Quattrocento',
   //     'Raleway, cursive' => 'Raleway',
   //     'Ubuntu, sans-serif' => 'Ubuntu', 
  //      'Yanone Kaffeesatz, sans-serif' => 'Yanone Kaffeesatz'
  //  );
    return $google_faces;
}




//ajax functions		
add_action( 'wp_ajax_nectar_check_font_attrs', 'nectar_check_google_font_attrs' );
add_action( 'wp_ajax_nectar_font_preview', 'nectar_google_font_preview' );

function nectar_check_google_font_attrs(){
	
	$font_family = $_POST['font_family'];
	
	global $google_fonts;
	 
	$google_fonts_object = $google_fonts;
	
	$attrs = null;
	 
	foreach($google_fonts_object as $obj => $props) {
		if($font_family == $props['family']) {
			$attrs = array(array(
				'weights' => $props['variants'],
				'subsets' => $props['subsets']
			));
			
			echo json_encode($attrs);
			
			die();
			
		} 
	}
	
	//default OS fonts
	if($attrs == null) {

		$attrs = array(array(
			'weights' => array('regular'),
			'subsets' => array('default')
		));
		
		echo json_encode($attrs);
		
		die();
	}

}

function nectar_google_font_preview(){
	//to-do
}



function font_sizes() {
	$sizes = range( 9, 110 );
	$sizes = apply_filters( 'of_recognized_font_sizes', $sizes );
	$sizes = array_map( null, $sizes );
	
	$sizes = array_merge(array('-'=>'Font Size'),$sizes);
	return $sizes;
}

function font_styles() {
	$styles = array(
	    '-'      => __( 'Font Styles', NECTAR_THEME_NAME ),
	    '100'      => __( '100', NECTAR_THEME_NAME ),
	    '200'      => __( '200', NECTAR_THEME_NAME ),
	    '200italic'      => __( '200 Italic', NECTAR_THEME_NAME ),
	    '300'      => __( '300', NECTAR_THEME_NAME ),
	    '300italic'      => __( '300 Italic', NECTAR_THEME_NAME ),
		'regular'      => __( 'Regular', NECTAR_THEME_NAME ),
		'italic'      => __( 'Italic', NECTAR_THEME_NAME ),
		'600'    => __( '600', NECTAR_THEME_NAME ),
		'600italic' => __( '600 Italic', NECTAR_THEME_NAME ),
		'700'      => __( '700', NECTAR_THEME_NAME ),
		'700italic'      => __( '700 Italic', NECTAR_THEME_NAME ),
		'800'      => __( '800', NECTAR_THEME_NAME ),
		'800italic'      => __( '800 Italic', NECTAR_THEME_NAME ),
		'900'      => __( '900', NECTAR_THEME_NAME ),
		'900italic'      => __( '900 Italic', NECTAR_THEME_NAME ),
		);
	return apply_filters( 'font_styles', $styles );
}

$typography_options = array(
	'sizes' => font_sizes(),
	'styles' => font_styles()
);

$sizes = $typography_options['sizes'];
$styles = $typography_options['styles'];


$font_sizes = null;
$font_styles = null;

$count = 0;
foreach ( $sizes as $size ) {
	$count++;
	
	($count == 1) ? $font_sizes['-'] = $size : $font_sizes[$size.'px'] = $size . 'px';

}

foreach ( $styles as $weight => $style) { 
	$font_styles[$weight] = $style;
}



$typography_mixed_fonts = array_merge( options_typography_get_os_fonts() , options_typography_get_google_fonts() );
asort($typography_mixed_fonts);

$typography_mixed_fonts = array_merge(array('-'=>'Font Family'),$typography_mixed_fonts); 
 



//processing 
$options = get_option('salient'); 

if ( !function_exists( 'options_typography_google_fonts' ) ) {
	function options_typography_google_fonts() {
		
		$all_google_fonts = array_keys( options_typography_get_google_fonts() );
		
		global $options;
		
		$body = $options['body_font'];
		$navigation = $options['navigation_font'];
		$navigation_dropdown = $options['navigation_dropdown_font'];
		$nectar_slider_heading = $options['nectar_slider_heading_font'];
    $home_slider_caption = $options['home_slider_caption_font'];
    $testimonial = $options['testimonial_font'];
    $page_heading = $options['page_heading_font'];
    $page_heading_subtitle = $options['page_heading_subtitle_font'];
		$h1 = $options['h1_font'];
		$h2 = $options['h2_font'];
		$h3 = $options['h3_font'];
		$h4 = $options['h4_font'];
		$h5 = $options['h5_font'];
    $italic = $options['i_font'];
		$sidebar_carousel_footer_header = $options['sidebar_footer_h_font'];
		$team_member_names = $options['team_member_h_font'];
		
		//$google_mixed = of_get_option('google_mixed', false);
		//$google_mixed_2 = of_get_option('google_mixed_2', 'Arvo, serif');

		// Get the font face for each option and put it in an array
		$selected_fonts = array(
			$body , 
			$navigation , 
			$navigation_dropdown , 
			$nectar_slider_heading ,
			$home_slider_caption , 
      $testimonial,
      $page_heading,
      $page_heading_subtitle,
			$h1,
			$h2,
			$h3,
			$h4,
			$h5,
      $italic,
			$sidebar_carousel_footer_header , 
			$team_member_names 
		);
		
		$locations = array(
			'body_font' , 
			'navigation_font' , 
			'navigation_dropdown_font' , 
			'nectar_slider_heading_font' , 
			'home_slider_caption_font' , 
      'testimonial_font',
      'page_heading_font',
      'page_heading_subtitle_font',
			'h1_font' , 
			'h2_font' , 
			'h3_font' , 
			'h4_font' , 
			'h5_font' , 
      'i_font',
			'sidebar_footer_h_font', 
			'team_member_h_font'
		);
		
		// Remove any duplicates in the list
		//$selected_fonts = array_unique($selected_fonts);
		// Check each of the unique fonts against the defined Google fonts
		// If it is a Google font, go ahead and call the function to enqueue it
		$count = 0;
		foreach ( $selected_fonts as $font) {
			if ( in_array( $font, $all_google_fonts ) ) {
				options_typography_enqueue_google_font($font,$locations[$count]);
			}
			
			//custom included fonts
			if($font == 'Lovelo, sans-serif') {
				if( !function_exists('nectar_lovelo_font')) {
					function nectar_lovelo_font(){
						echo "
						<!-- A font fabric font - http://fontfabric.com/lovelo-font/ -->
						<style> @font-face { font-family: 'Lovelo'; src: url('".get_template_directory_uri()."/css/fonts/Lovelo_Black.eot'); src: url('".get_template_directory_uri()."/css/fonts/Lovelo_Black.eot?#iefix') format('embedded-opentype'), url('".get_template_directory_uri()."/css/fonts/Lovelo_Black.woff') format('woff'),  url('".get_template_directory_uri()."/css/fonts/Lovelo_Black.ttf') format('truetype'), url('".get_template_directory_uri()."/css/fonts/Lovelo_Black.svg#loveloblack') format('svg'); font-weight: normal; font-style: normal; } </style>";
					}
				}
				add_action('wp_head', 'nectar_lovelo_font');	
			}
			
			$count++;
		}
	}
}

if(!empty($options['use-custom-fonts']) && $options['use-custom-fonts'] == 1){
	add_action( 'wp_enqueue_scripts', 'options_typography_google_fonts' ,5);	
}



function options_typography_enqueue_google_font($font, $location) {
	

	$font = explode(',', $font);
	$font = $font[0];

	$font = str_replace(" ", "+", $font);
	
	global $options;
	
	//handle font styles
	$enqueued_fonts_with_weight[] = '';
	$enqueued_fonts[] = '';
	
	$subset = $options[$location.'_subset'];
	
	if(!empty($options[$location.'_style']) ) {
		
		$weight = null;
		if($options[$location.'_style'] == '-') 
			$weight = '400';
		else 
			$weight = $options[$location.'_style'];

		
		if(!in_array($font.'-'.$weight, $enqueued_fonts_with_weight)){
			// using subset
			if( $subset != 'subset' && $subset != 'latin' ) {
				wp_enqueue_style( "options_typography_$font-$weight", "https://fonts.googleapis.com/css?family=$font:$weight&subset=$subset", false, null, 'all' );
			}
			else {
				wp_enqueue_style( "options_typography_$font-$weight", "https://fonts.googleapis.com/css?family=$font:$weight", false, null, 'all' );
			}
		}// in array check
		$enqueued_fonts_with_weight[] = $font.'-'.$weight;
	}


}

?>